"""Conservative, network-free storage pricing extractors.

Generic extractors require a unit identity and an unambiguous labelled rate.
They are fallbacks, not claims of support for every booking platform.
"""
import hashlib
import json
import re
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from urllib.parse import urlparse

from bs4 import BeautifulSoup
from national_storage_scraper import site_units, inventory_state

MONEY = re.compile(r'(?:NZ\$|AU\$|A\$|\$)\s*([\d,]+(?:\.\d{1,2})?)(?![\d.])', re.I)
AREA = re.compile(r'(\d+(?:\.\d+)?)\s*(?:m\s*[²2]|sq\.?\s*m|sqm)\b', re.I)
DIMS = re.compile(r'(\d+(?:\.\d+)?)\s*m?\s*[x×]\s*(\d+(?:\.\d+)?)\s*m\b', re.I)
STORAGE = re.compile(r'\b(?:storage|unit|locker|container|parking|caravan|warehouse|shed)\b', re.I)
FEE = re.compile(r'\b(?:insurance|deposit|bond|admin|administration|padlock|delivery|removal)\b', re.I)
WORDS = {'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6,
         'twelve': 12, 'first': 1, 'second': 2}
NUMBER = r'(\d+(?:st|nd|rd|th)?|one|two|three|four|five|six|twelve|first|second)'


def text(node):
    # BeautifulSoup's space separator turns m<sup>2</sup> into "m 2".
    return re.sub(r'\s+', ' ', node.get_text(' ', strip=True)).strip()


def decimal(value):
    try:
        number = Decimal(str(value).replace(',', '').strip())
        return format(number, 'f') if number.is_finite() and number >= 0 else ''
    except (InvalidOperation, ValueError):
        return ''


def money(value):
    if re.search(r'\$\s*[\d,.]+\s*[-–—]\s*(?:\$\s*)?\d', value):
        return ''
    hits = {decimal(m) for m in MONEY.findall(value)}
    return hits.pop() if len(hits) == 1 else ''


def period(value):
    patterns = [('4_weeks', r'(?:per|/|every)\s*(?:4|four)\s*weeks?'),
                ('fortnight', r'(?:per|/|every)\s*(?:fortnight|2\s*weeks?)'),
                ('month', r'(?:per\s*|/\s*|\b)(?:month(?:ly)?|mo\b|pcm\b)'),
                ('week', r'(?:per\s*|/\s*|\b)(?:week(?:ly)?|wk\b|pw\b)'),
                ('day', r'(?:per\s*|/\s*|\b)(?:daily|day\b)')]
    # Remove promotion duration: "for 2 months" is not a billing period.
    value = re.sub(r'(?:for|first)\s+' + NUMBER + r'\s+months?', '', value, flags=re.I)
    found = []
    for name, pattern in patterns:
        if re.search(pattern, value, re.I):
            found.append(name)
            value = re.sub(pattern, '', value, flags=re.I)
    return found[0] if len(found) == 1 else ''


def promotion(value):
    pct = re.search(r'\b(\d+(?:\.\d+)?)\s*%\s*(?:off|discount)?', value, re.I)
    percentage = pct.group(1) if pct and Decimal(pct.group(1)) <= 100 else ''
    if not percentage and re.search(r'\bhalf\s+price\b', value, re.I):
        percentage = '50'
    if not percentage and re.search(r'(?:first\s+month\s+free|free\s+first\s+month)', value, re.I):
        percentage = '100'
    duration = re.search(r'(?:for\s+(?:the\s+)?|first\s+)' + NUMBER + r'\s+months?', value, re.I)
    if not duration:
        duration = re.search(NUMBER + r'\s+months?\s+(?:at\s+)?(?:\d+\s*%|half\s+price|free)', value, re.I)
    if not duration:
        duration = re.search(NUMBER + r'\s+month', value, re.I) if re.search(r'\b(?:first|1st)\s+month\b', value, re.I) else None
    months = ''
    if duration:
        number = duration.group(1).lower()
        months = str(WORDS.get(number, re.sub(r'(st|nd|rd|th)$', '', number)))
    return percentage, months


def tax_basis(value, country, url):
    inc = bool(re.search(r'(?:\binc(?:l(?:uded?|uding|usive)?)?\.?\s*(?:of\s*)?gst|gst\s*inc(?:luded|lusive)?)', value, re.I))
    exc = bool(re.search(r'(?:\bex(?:cl(?:uded?|uding|usive)?)?\.?\s*(?:of\s*)?gst|\+\s*gst|plus\s+gst)', value, re.I))
    if inc and exc:
        return 'ambiguous'
    if inc:
        return 'inclusive_explicit'
    if exc:
        return 'exclusive_explicit'
    if country == 'AU' and urlparse(url).hostname in ('nationalstorage.com.au', 'www.nationalstorage.com.au'):
        return 'inclusive_published_terms'
    return 'unknown'


def inclusive(amount, basis, country):
    if not amount:
        return ''
    if basis.startswith('inclusive_'):
        return amount
    if basis == 'exclusive_explicit' and country in ('AU', 'NZ'):
        rate = Decimal('1.10' if country == 'AU' else '1.15')
        return format((Decimal(amount) * rate).quantize(Decimal('.01'), rounding=ROUND_HALF_UP), 'f')
    return ''


def unit_size(value):
    area = AREA.search(value)
    dims = DIMS.search(value)
    if area:
        return area.group(1), dims.group() if dims else ''
    if dims:
        return format(Decimal(dims.group(1)) * Decimal(dims.group(2)), 'f'), dims.group()
    return '', ''


def availability(value):
    # Word boundaries keep "unavailable" from becoming "available".
    match = re.search(r'\b(sold out|unavailable|not available|out of stock|waiting list|waitlist)\b', value, re.I)
    if match:
        return 'unavailable', match.group()
    match = re.search(r'\b(in stock|available|limited availability)\b', value, re.I)
    return ('advertised_available', match.group()) if match else ('unknown', '')


def make_offer(record, url, captured_at, adapter, label, regular='', current='',
               rate_period='', evidence='', promo='', unit_id='', features='', page_tax=''):
    size, dimensions = unit_size(label)
    basis = tax_basis(evidence, record['country'], url)
    if basis == 'unknown':
        basis = page_tax or 'unknown'
    pct, months = promotion(promo)
    stock, stock_text = availability(evidence)
    return {
        **{key: record.get(key, '') for key in ('store_id', 'brand', 'store_name', 'address', 'city', 'state', 'postcode', 'country', 'lat', 'lng', 'nearest_kss_site', 'nearest_kss_km')},
        'captured_at': captured_at, 'source_url': url, 'adapter': adapter,
        'unit_id': unit_id, 'unit_type': 'parking' if re.search(r'\b(parking|caravan)\b', label, re.I) else 'storage unit',
        'unit_label': label, 'size_m2': size, 'dimensions': dimensions, 'features': features,
        'regular_price_advertised': regular, 'online_price_advertised': current,
        'regular_price_inc_gst': inclusive(regular, basis, record['country']),
        'online_price_inc_gst': inclusive(current, basis, record['country']),
        'gst_basis': basis, 'currency': 'NZD' if record['country'] == 'NZ' else 'AUD' if record['country'] == 'AU' else '',
        'billing_period': rate_period, 'price_qualifier': 'from' if re.search(r'\bfrom\s*(?:NZ|AU|A)?\s*\$', evidence, re.I) else 'advertised',
        'promo_text': (f'{pct}% for {months} month' + ('' if months == '1' else 's')) if pct and months and not re.search(r'\bup to\b', promo, re.I) else promo,
        'promo_pct': pct, 'promo_months': months,
        'availability': stock, 'availability_evidence': stock_text,
        'inventory_coverage': 'partial_public_pages', 'evidence_text': evidence[:2500],
    }


def json_nodes(value):
    if isinstance(value, list):
        for item in value:
            yield from json_nodes(item)
    elif isinstance(value, dict):
        yield value
        for key in ('@graph', 'itemListElement', 'item'):
            if key in value:
                yield from json_nodes(value[key])


def parse_page(html, record, url, captured_at):
    soup = BeautifulSoup(html, 'html.parser')
    content = text(soup)
    page_tax = tax_basis(content, record['country'], url)
    offers, warnings = [], []
    if soup.select('.unit-details') and urlparse(url).hostname in (
            'nationalstorage.com.au', 'www.nationalstorage.com.au', 'nationalstorage.nz', 'www.nationalstorage.nz'):
        for raw in site_units(soup, record, url):
            offer = make_offer(record, url, captured_at, 'national_storage',
                               raw['size_m2'] + ' m2 ' + raw['dimensions'],
                               raw['standard_price_aud'], raw['advertised_price_aud'],
                               raw['billing_period'], raw['unit_text'],
                               raw['promotion'] + ' ' + raw['promotion_duration'],
                               raw['unit_id'], raw['features'], page_tax)
            offer.update(availability=raw['availability'], availability_evidence=raw['availability_evidence'])
            offers.append(offer)
        if len(offers) != len(soup.select('.unit-details')):
            warnings.append('National Storage card/extraction count mismatch')
    else:
        # Schema.org: only storage products with explicit Offer prices.
        for script in soup.select('script[type="application/ld+json"]'):
            try:
                data = json.loads(script.string or script.get_text())
            except (ValueError, TypeError):
                warnings.append('Invalid JSON-LD')
                continue
            for product in json_nodes(data):
                kinds = product.get('@type', [])
                if isinstance(kinds, str):
                    kinds = [kinds]
                label = str(product.get('name', ''))
                description = label + ' ' + str(product.get('description', ''))
                if 'Product' not in kinds or not STORAGE.search(description) or not unit_size(description)[0]:
                    continue
                rates = product.get('offers', [])
                if isinstance(rates, dict):
                    rates = [rates]
                for rate in rates:
                    if not isinstance(rate, dict) or rate.get('@type') not in ('Offer', None):
                        continue
                    spec = rate.get('priceSpecification', {})
                    if not isinstance(spec, dict):
                        spec = {}
                    amount = decimal(rate.get('price', spec.get('price', '')))
                    if not amount:
                        continue
                    evidence = description + ' ' + str(rate.get('description', ''))
                    if spec.get('valueAddedTaxIncluded') is True:
                        evidence += ' including GST'
                    elif spec.get('valueAddedTaxIncluded') is False:
                        evidence += ' excluding GST'
                    duration = spec.get('billingDuration', '')
                    if not isinstance(duration, str):
                        duration = ''
                    unit_code = str(spec.get('unitCode', ''))
                    rate_period = {'MON': 'month', 'WEE': 'week', 'DAY': 'day'}.get(unit_code, '')
                    rate_period = rate_period or {'P1M': 'month', 'P1W': 'week', 'P1D': 'day'}.get(duration, '') or period(evidence)
                    offer = make_offer(record, url, captured_at, 'schema_product', description,
                                       '', amount, rate_period, evidence, evidence,
                                       str(product.get('sku', product.get('productID', ''))), page_tax=page_tax)
                    currency = rate.get('priceCurrency', spec.get('priceCurrency'))
                    if currency:
                        offer['currency'] = currency
                    stock = str(rate.get('availability', '')).rsplit('/', 1)[-1]
                    if stock:
                        offer.update(availability={'InStock': 'advertised_available', 'OutOfStock': 'unavailable',
                                                   'SoldOut': 'unavailable'}.get(stock, 'unknown'), availability_evidence=stock)
                    offers.append(offer)
        # Table rates are paired with their column headers, never page-wide $ matches.
        for table in soup.select('table'):
            heading = table.find('tr')
            if not heading:
                continue
            headers = [text(c) for c in heading.find_all(['th', 'td'], recursive=False)]
            rate_indices = [i for i, h in enumerate(headers) if re.search(r'price|rate|weekly|monthly|per month|per week|/\s*(?:month|week|mo\b|wk\b)', h, re.I) and not FEE.search(h)]
            if not rate_indices:
                continue
            caption = table.find('caption')
            table_period = period(text(caption)) if caption else ''
            for tr in table.find_all('tr')[1:]:
                cells = tr.find_all(['td', 'th'], recursive=False)
                values = [text(c) for c in cells]
                label = ' '.join(v for i, v in enumerate(values) if i not in rate_indices and not MONEY.search(v))
                if len(cells) != len(headers) or any(c.get('colspan') or c.get('rowspan') for c in cells):
                    warnings.append('Skipped complex table row')
                    continue
                if not unit_size(label)[0] or FEE.search(label):
                    continue
                regular_indices = [i for i in rate_indices if re.search(r'regular|standard|normal|was', headers[i], re.I)]
                sale_indices = [i for i in rate_indices if re.search(r'online|sale|special|discount|now', headers[i], re.I)]
                pairs = []
                if len(regular_indices) == len(sale_indices) == 1:
                    ri, si = regular_indices[0], sale_indices[0]
                    rp, sp = period(headers[ri]), period(headers[si])
                    if not (rp and sp and rp != sp):
                        pairs = [(ri, si)]
                if not pairs:
                    pairs = [(None, i) for i in rate_indices]
                for ri, si in pairs:
                    current = money(values[si])
                    if not current and not re.search(r'sold out|unavailable|not available|waitlist|\bPOA\b|contact|enquire|call', values[si], re.I):
                        continue
                    evidence = ' | '.join(f'{h}: {v}' for h, v in zip(headers, values))
                    offer = make_offer(record, url, captured_at, 'html_table', label,
                                       money(values[ri]) if ri is not None else '', current,
                                       period(headers[si] + ' ' + values[si]) or (period(headers[ri]) if ri is not None else '') or table_period,
                                       evidence, evidence, page_tax=page_tax)
                    offers.append(offer)
        # Only explicit unit components; never broad sections containing many units.
        selector = ('.unit-card, .storage-unit, .unit-item, [data-testid="unit-card"], .storage-card, .unitCard, '
                    '.elementor-price-table, .pricing-card, .price-card')
        for card in soup.select(selector):
            if card.select_one(selector):
                continue
            label_node = card.select_one('h2, h3, h4, h5, .unit-name, .unit-size')
            label = text(label_node) if label_node else text(card)
            if not unit_size(label)[0] or FEE.search(label):
                continue
            old = card.select_one('del, s, .original-price, .was-price, .regular-price')
            current_node = card.select_one('.sale-price, .online-price, .current-price, [itemprop="price"]')
            regular = money(text(old)) if old else ''
            if current_node:
                current = money(text(current_node))
            else:
                clone = BeautifulSoup(str(card), 'html.parser')
                for node in clone.select('del, s, .original-price, .was-price, .regular-price'):
                    node.decompose()
                current = money(text(clone))
            evidence = text(card)
            if not current and not regular and not re.search(r'sold out|unavailable|not available|waitlist|\bPOA\b|contact|enquire|call', evidence, re.I):
                continue
            features = '; '.join(text(n) for n in card.select('.unit-access, .unit-features, .features, .feature, [data-feature]'))
            offers.append(make_offer(record, url, captured_at, 'unit_card', label,
                                     regular, current, period(evidence), evidence, evidence,
                                     card.get('data-unit-id', card.get('data-unit-type-id', '')), features, page_tax=page_tax))
    # Keep distinct unit IDs/features; identical repeated DOM cards are deduplicated.
    unique = {}
    for offer in offers:
        key = tuple(offer[k] for k in ('unit_id', 'unit_label', 'features', 'billing_period', 'regular_price_advertised', 'online_price_advertised', 'currency'))
        if key not in unique:
            offer['offer_id'] = hashlib.sha256(json.dumps([record['store_id'], *key]).encode()).hexdigest()[:20]
            unique[key] = offer
    promos, seen = [], set()
    for node in soup.select('p, h1, h2, h3, h4, li, .promotion, .promo, .discount__text'):
        value = text(node)
        pct, months = promotion(value)
        if not pct or len(value) > 600 or value in seen or FEE.search(value):
            continue
        seen.add(value)
        promos.append({'store_id': record['store_id'], 'brand': record['brand'], 'store_name': record['store_name'],
                       'captured_at': captured_at, 'source_url': url, 'promo_text': value,
                       'promo_pct': pct, 'promo_months': months, 'eligibility': 'page_offer_check_terms'})
    platforms = sorted({name for name in ('rapidstor', 'storman', 'sitelink', 'storeganise', 'vantaj')
                        if name in html.lower()})
    state, note = inventory_state(soup, list(unique.values()))
    if unique:
        state = 'public_units_partial'
    elif state == 'no_units_in_html':
        state = 'platform_adapter_required' if platforms else 'promotions_only' if promos else 'no_recognized_pricing'
    return list(unique.values()), promos, {'status': state, 'warnings': warnings,
                                           'platforms': platforms, 'note': note}
