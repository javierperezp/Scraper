"""Robots-aware, rate-limited public GET transport. No browser impersonation."""
import hashlib
import json
import re
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin, urlparse, urlunparse

import requests
from bs4 import BeautifulSoup
from protego import Protego

from national_storage_scraper import access_problem

USER_AGENT = 'StoragePriceResearch/2.0'
UNSAFE_PATH = re.compile(r'/(?:checkout|cart|payment|login|log-in|sign-in|account|customer-portal|orders?|reserve|reservation|set-unit|logout)(?:/|$)', re.I)


class AccessFailure(Exception):
    def __init__(self, status, detail, http_status=''):
        super().__init__(detail)
        self.status, self.detail, self.http_status = status, detail, http_status


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def public_url(value):
    value = (value or '').strip()
    if not value or value.casefold() in ('nan', 'none', 'null'):
        return ''
    if not value.startswith(('http://', 'https://')):
        value = 'https://' + value
    parsed = urlparse(value)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
        return ''
    try:
        port = parsed.port
    except ValueError:
        return ''
    if port not in (None, 80, 443):
        return ''
    # Only public DNS hostnames. No supplied CSV row can target local services.
    host = parsed.hostname.lower()
    if '.' not in host or re.fullmatch(r'[\d.]+', host) or host.endswith(('.local', '.localhost', '.internal')):
        return ''
    return urlunparse(parsed._replace(fragment=''))


def publisher(url):
    return (urlparse(url).hostname or '').lower().removeprefix('www.')


class PublicClient:
    def __init__(self, delay=4, timeout=25, cache_dir=None, session_factory=requests.Session):
        self.delay, self.timeout = delay, timeout
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self.session_factory = session_factory
        self.states, self.state_lock = {}, threading.Lock()

    def state(self, url):
        # www and bare hosts share throttling and stop-on-block state.
        key = publisher(url)
        with self.state_lock:
            if key not in self.states:
                session = self.session_factory()
                session.headers.update({'User-Agent': USER_AGENT, 'Accept-Language': 'en-AU,en-NZ;q=0.9,en;q=0.8'})
                self.states[key] = {'lock': threading.RLock(), 'session': session, 'last': 0,
                                    'robots': {}, 'stopped': None, 'delay': self.delay}
            return self.states[key]

    def request(self, url, state):
        time.sleep(max(0, state['last'] + state['delay'] - time.monotonic()))
        try:
            response = state['session'].get(url, timeout=self.timeout, allow_redirects=False, stream=True)
            # Bound downloads without disabling certificate verification.
            body = bytearray()
            for chunk in response.iter_content(chunk_size=65536):
                body.extend(chunk)
                if len(body) > 8_000_000:
                    raise AccessFailure('response_too_large', 'Response exceeds the 8 MB safety limit')
            response._content = bytes(body)
            response._content_consumed = True
            response.close()
        except requests.RequestException as exc:
            name = type(exc).__name__
            status = 'network_proxy_error' if isinstance(exc, requests.exceptions.ProxyError) else 'network_error'
            failure = AccessFailure(status, f'{name}: request to {urlparse(url).hostname} failed; no inventory inferred')
            state['stopped'] = failure
            raise failure from None
        finally:
            state['last'] = time.monotonic()
        if response.status_code == 403 and response.text.strip().lower() == 'domain forbidden':
            failure = AccessFailure('network_policy_denied', 'Network/upstream domain filter denied this destination; website access policy could not be established', 403)
            state['stopped'] = failure
            raise failure
        problem = access_problem(response)
        if problem:
            failure = AccessFailure(problem, 'Access restriction or service failure; this publisher has been paused', response.status_code)
            state['stopped'] = failure
            raise failure
        return response

    def robots(self, url, state):
        parsed = urlparse(url)
        origin = f'{parsed.scheme}://{parsed.netloc}'
        if origin in state['robots']:
            result = state['robots'][origin]
            if isinstance(result, AccessFailure):
                raise result
            return result
        robots_url = origin + '/robots.txt'
        try:
            for _ in range(4):
                response = self.request(robots_url, state)
                if response.status_code in (301, 302, 303, 307, 308):
                    target = public_url(urljoin(robots_url, response.headers.get('Location', '')))
                    if not target or publisher(target) != publisher(url) or urlparse(target).path != '/robots.txt':
                        raise AccessFailure('robots_unverified', 'Robots redirect requires manual review', response.status_code)
                    robots_url = target
                    continue
                break
            if response.status_code in (404, 410):
                # RFC 9309: explicitly missing robots.txt does not forbid crawling.
                robot = Protego.parse('User-agent: *\nDisallow:')
                evidence = {'status': 'absent', 'http_status': response.status_code}
            elif response.status_code == 200 and not re.search(r'<(?:!doctype\s+html|html|head|body)\b', response.text, re.I):
                robot = Protego.parse(response.text)
                evidence = {'status': 'verified', 'http_status': 200}
            else:
                raise AccessFailure('robots_unverified', 'Cannot verify robots.txt rules; no facility request made', response.status_code)
            delay = robot.crawl_delay(USER_AGENT) or 0
            rate = robot.request_rate(USER_AGENT)
            state['delay'] = max(state['delay'], delay, rate.seconds / rate.requests if rate and rate.requests else 0)
            evidence.update(url=robots_url, checked_at=timestamp(), sha256=hashlib.sha256(response.content).hexdigest())
            state['robots'][origin] = (robot, evidence)
            return robot, evidence
        except AccessFailure as failure:
            state['robots'][origin] = failure
            raise

    def fetch(self, url):
        return self._fetch(url, ('text/html', 'application/xhtml'), '.html')

    def fetch_json(self, url):
        """Public JSON metadata, under the same robots/redirect/rate-limit policy."""
        return self._fetch(url, ('application/json',), '.body')

    def _fetch(self, url, accepted_types, body_suffix):
        url = public_url(url)
        if not url:
            raise AccessFailure('invalid_url', 'Not a valid public HTTP(S) URL')
        initial = url
        state = self.state(url)
        with state['lock']:
            if state['stopped']:
                previous = state['stopped']
                raise AccessFailure('publisher_paused', f'No retry after {previous.status}: {previous.detail}', previous.http_status)
            for _ in range(5):
                if UNSAFE_PATH.search(urlparse(url).path):
                    raise AccessFailure('interactive_route_skipped', 'Checkout, account and reservation routes are not collected')
                robot, policy = self.robots(url, state)
                if not robot.can_fetch(url, USER_AGENT):
                    raise AccessFailure('robots_disallow', 'URL disallowed by robots.txt')
                response = self.request(url, state)
                if response.status_code in (301, 302, 303, 307, 308):
                    target = public_url(urljoin(url, response.headers.get('Location', '')))
                    if not target or publisher(target) != publisher(initial):
                        raise AccessFailure('external_redirect_review', 'Cross-publisher redirect requires a reviewed facility URL', response.status_code)
                    if urlparse(url).scheme == 'https' and urlparse(target).scheme != 'https':
                        raise AccessFailure('insecure_redirect', 'HTTPS to HTTP redirect was not followed', response.status_code)
                    url = target
                    continue
                if response.status_code != 200:
                    raise AccessFailure('http_error', f'HTTP {response.status_code}', response.status_code)
                ctype = response.headers.get('Content-Type', '').lower()
                if ctype and not any(kind in ctype for kind in accepted_types):
                    raise AccessFailure('unsupported_content_type', 'Expected ' + '/'.join(accepted_types) + '; found ' + ctype[:100], 200)
                captured = timestamp()
                evidence = {'url': url, 'requested_url': initial, 'captured_at': captured,
                            'sha256': hashlib.sha256(response.content).hexdigest(), 'robots': policy, 'content_type': ctype}
                if self.cache_dir:
                    self.cache_dir.mkdir(parents=True, exist_ok=True)
                    stem = hashlib.sha256((url + captured).encode()).hexdigest()
                    (self.cache_dir / (stem + body_suffix)).write_bytes(response.content)
                    evidence['encoding'] = response.encoding or 'utf-8'
                    (self.cache_dir / (stem + '.json')).write_text(json.dumps(evidence, indent=2), encoding='utf-8')
                return response.text, url, captured, evidence
            raise AccessFailure('redirect_limit', 'Too many redirects')


def unit_links(html, current_url, record):
    """Only explicit read-only pricing/unit links on the same publisher.

    A link is a candidate, never authorization: fetch() checks robots on every URL.
    Different booking hosts are reported separately for adapter review.
    """
    soup = BeautifulSoup(html, 'html.parser')
    links = []
    current_path = urlparse(current_url).path.rstrip('/')
    location = [w for w in re.findall(r'[a-z0-9]+', record.get('city', '').lower()) if len(w) > 2]
    for node in soup.select('a[href]'):
        label = node.get_text(' ', strip=True)
        if not re.search(r'view\s+all\s+(?:units|sizes)|(?:unit|storage)\s+(?:prices|rates|sizes)|(?:prices|pricing|rates)', label, re.I):
            continue
        target = public_url(urljoin(current_url, node['href']))
        if not target or target == current_url or publisher(target) != publisher(current_url):
            continue
        path = urlparse(target).path.lower()
        if UNSAFE_PATH.search(path) or 'sitemap' in path:
            continue
        descendant = current_path and path.startswith(current_path.lower() + '/')
        local = location and all(word in path for word in location)
        if not descendant and not local and not re.search(r'view\s+all\s+(?:units|sizes)', label, re.I):
            # Brand-wide pricing pages must not be assigned to a specific branch.
            continue
        if target not in links:
            links.append(target)
    return links
