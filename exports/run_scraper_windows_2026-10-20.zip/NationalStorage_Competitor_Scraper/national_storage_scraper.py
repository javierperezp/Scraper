"""National Storage AU public facility-page listing scraper.

Install: py -m pip install -U requests beautifulsoup4
Run:     py national_storage_scraper.py --input cannot_scrape.csv --limit 5
All AU:  py national_storage_scraper.py --input cannot_scrape.csv --url-map verified_facility_urls.csv --limit 0

Only fetches publicly allowed pages. Does not bypass Cloudflare, CAPTCHAs or access restrictions.
The robots-disallowed 'View all units' route is not collected. Inventories remain partial.
"""
import argparse
import csv
import hashlib
import json
import random
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse, urljoin

try:
    from bs4 import BeautifulSoup
    from protego import Protego
    import requests
except ImportError:
    sys.exit('Missing dependency. Run: py -m pip install -r requirements.txt')

BASE = 'https://nationalstorage.com.au'
COLUMNS = ['scraped_at', 'store_id', 'store_name', 'address', 'city', 'state', 'postcode',
           'nearest_kss_site', 'nearest_kss_km', 'centre_url', 'size_m2', 'price_text', 'availability',
           'promotion', 'standard_price', 'advertised_price', 'billing_period', 'dimensions', 'unit_text',
           'standard_price_aud', 'advertised_price_aud', 'promotion_duration', 'currency',
           'unit_type', 'features', 'unit_id', 'source_url', 'availability_evidence', 'terms',
           'inventory_coverage', 'size_category', 'facility_name',
           'facility_address', 'facility_city', 'facility_state', 'facility_postcode']
STATUS_COLUMNS = ['scraped_at', 'store_id', 'store_name', 'centre_url', 'http_status',
                  'status', 'units_found', 'details', 'country', 'original_url',
                  'facility_request_attempted', 'robots_http_status', 'robots_status',
                  'inventory_coverage', 'all_units_url', 'all_units_access', 'unit_cards_in_html',
                  'facility_name']
CHALLENGES = ('just a moment', 'checking your browser', 'verifying you are human',
              'cf-challenge', '/cdn-cgi/challenge-platform', 'attention required')
UNIT_SELECTOR = ', '.join(['[class*="unit-card"]', '[class*="unitCard"]', '[class*="UnitCard"]',
                            '[data-testid*="unit"]', '[class*="storage-unit"]',
                            '[class*="unit-item"]', '[class*="unitItem"]'])
SIZE_RE = re.compile(r'(\d+(?:\.\d+)?)\s*(?:m²|m2|sq\.?\s?m|sqm)(?!\w)', re.I)
PRICE_RE = re.compile(r'\$\s*[\d,]+(?:\.\d{1,2})?(?:\s*(?:/|per)\s*(?:week|month|4 weeks))?', re.I)


def access_problem(response):
    """Classify observed responses without treating a failed fetch as inventory."""
    body = response.text.lower()
    if (any(c in body[:16000] for c in CHALLENGES)
            or 'sorry, you have been blocked' in body[:16000]):
        return 'cloudflare_or_access_block'
    return {401: 'authentication_required', 403: 'access_denied',
            429: 'rate_limited', 503: 'service_unavailable'}.get(response.status_code, '')


def check_robots(session):
    """Use one explicit request; save safe diagnostics, never challenge tokens."""
    evidence = {'url': BASE+'/robots.txt', 'checked_at': datetime.now(timezone.utc).isoformat(),
                'http_status': None, 'status': '', 'details': '', 'request_count': 1}
    robot = Protego.parse('User-agent: *\nDisallow: /')
    try:
        response = session.get(evidence['url'], timeout=35, allow_redirects=False)
    except requests.RequestException as exc:
        # Exception strings can contain proxy URLs with credentials. Only keep
        # the exception class and a fixed, non-sensitive explanation.
        evidence.update(status='network_error',
                        details=f'{type(exc).__name__}: robots.txt request failed before access rules could be verified')
        return robot, evidence
    evidence['http_status'] = response.status_code
    evidence['body_sha256'] = hashlib.sha256(response.text.encode('utf-8')).hexdigest()
    evidence['status'] = access_problem(response)
    if evidence['status']:
        evidence['details'] = 'Access rules unavailable; no facility requests made and no bypass attempted'
        title = BeautifulSoup(response.text, 'html.parser').title
        evidence['page_title'] = title.get_text(' ', strip=True)[:160] if title else ''
        # A Ray ID is a request identifier the site owner can use to diagnose
        # the denial. Do not retain the IP or full challenge page.
        ray = re.search(r'Cloudflare Ray ID:\s*(?:<[^>]*>\s*)*([a-f0-9]{16,32})', response.text, re.I)
        if ray:
            evidence['cloudflare_ray_id'] = ray.group(1)
    elif response.status_code != 200:
        evidence.update(status='unverified', details='robots.txt did not return HTTP 200; redirects are not followed')
    elif re.search(r'<(?:!doctype\s+html|html|head|body)\b', response.text, re.I):
        evidence.update(status='unverified', details='robots.txt returned HTML instead of verified access rules')
    else:
        robot = Protego.parse(response.text)
        evidence.update(status='verified', details='robots.txt retrieved and parsed')
    return robot, evidence


def locate_csv(given):
    path = Path(given).expanduser()
    candidates = [path] if path.is_absolute() else [Path.cwd()/path, Path(__file__).resolve().parent/path]
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    names = '\n'.join('  ' + str(c) for c in candidates)
    sys.exit(f'ERROR: CSV not found. Checked:\n{names}\n\n'
             'Save cannot_scrape.csv alongside national_storage_scraper.py, '
             'or use --input "C:\\full\\path\\cannot_scrape.csv"')


def centre_url(raw):
    url = (raw or '').strip()
    if not url or url.lower() in ('nan', 'none'):
        return ''
    if url.startswith('/'): url = BASE + url
    if not url.startswith(('http://', 'https://')): url = 'https://' + url
    p = urlparse(url)
    if p.netloc.lower().removeprefix('www.') != 'nationalstorage.com.au': return ''
    # Ignore home page, search results, and unrelated paths
    if not re.fullmatch(r'/locations/[^/]+/?', p.path, re.I): return ''
    return BASE + p.path.rstrip('/') + '/'


def page_facility_schema(soup):
    for script in soup.select('script[type="application/ld+json"]'):
        try:
            document = json.loads(script.get_text())
        except (ValueError, TypeError):
            continue
        if isinstance(document, dict) and document.get('@type') == 'SelfStorage':
            return document
    return {}


def page_facility_name(soup):
    document=page_facility_schema(soup)
    if document.get('name'):
        return str(document['name'])
    heading = soup.select_one('h1')
    return heading.get_text(' ', strip=True) if heading else ''


def site_units(soup, record, url):
    """Parse the actual public facility-card markup observed on 20 Oct 2026.

    Checkout hrefs supply an identity only. They must never be requested.
    Prices are advertised amounts, not inferred discounted calculations.
    """
    rows = []
    seen = set()
    disclaimer = soup.select_one('.unit-disclaimer--location')
    terms = disclaimer.get_text(' ', strip=True) if disclaimer else ''
    facility_name = page_facility_name(soup)
    address = page_facility_schema(soup).get('address', {})

    def text(node, selector):
        element = node.select_one(selector)
        return element.get_text(' ', strip=True) if element else ''

    def amount(value):
        match = re.search(r'\$\s*([\d,]+(?:\.\d{1,2})?)', value)
        return match.group(1).replace(',', '') if match else ''

    for node in soup.select('.unit-details'):
        title_node = node.select_one('.unit-details__title h5')
        title = title_node.get_text('', strip=True) if title_node else ''
        area = SIZE_RE.search(title)
        if not area:
            continue
        link = node.select_one('.unit-details__cta-section a[href]')
        identity = re.search(r'/checkout/set-unit/([^/?]+/[^/?]+)/?', link['href']) if link else None
        unit_id = identity.group(1) if identity else ''
        key = unit_id or str(node)
        if key in seen:
            continue
        seen.add(key)
        regular = text(node, '.unit-details__price__information--struck') or text(node, '.unit-details__price__information--standard')
        sale = text(node, '.unit-details__price__information--sale')
        features = []
        for element in node.select('.unit-details__meta'):
            clone = BeautifulSoup(str(element), 'html.parser')
            for tooltip in clone.select('.simple-tooltip'):
                tooltip.decompose()
            feature = clone.get_text(' ', strip=True)
            if feature:
                features.append(feature)
        duration = re.search(r'for\s+\d+\s+months?', sale, re.I)
        unavailable = re.search(r'\b(sold out|unavailable|not available)\b', node.get_text(' ',strip=True), re.I)
        rows.append({
            'scraped_at':datetime.now(timezone.utc).isoformat(),
            **{k:record.get(k,'') for k in ['store_id','store_name','address','city','state','postcode','nearest_kss_site','nearest_kss_km']},
            'centre_url':url, 'source_url':url, 'size_m2':area.group(1),
            'facility_name':facility_name,
            'facility_address':address.get('streetAddress',''),
            'facility_city':address.get('addressLocality',''),
            'facility_state':address.get('addressRegion',''),
            'facility_postcode':address.get('postalCode',''),
            'dimensions':text(node,'.unit-details__squaremetre').strip('()'),
            'unit_type':'storage unit', 'size_category':title.split(' - ')[0],
            'features':'; '.join(features), 'unit_id':unit_id,
            'standard_price':regular, 'advertised_price':sale or regular,
            'standard_price_aud':amount(regular), 'advertised_price_aud':amount(sale or regular),
            'price_text':text(node,'.unit-details__price'), 'currency':'AUD',
            'billing_period':'month' if re.search(r'per month|/mo\b', regular+' '+sale, re.I) else '',
            'promotion':text(node,'.discount__text'),
            'promotion_duration':duration.group() if duration else '',
            'availability':'unavailable' if unavailable else 'offered_online' if identity else 'unknown',
            'availability_evidence':unavailable.group() if unavailable else 'Continue link advertised; stock and booking not verified' if identity else '',
            'terms':terms, 'unit_text':node.get_text(' ',strip=True),
            'inventory_coverage':'partial_facility_page',
        })
    return rows


def scrape_units(html, record, url):
    soup = BeautifulSoup(html, 'html.parser')
    if soup.select('.unit-details'):
        return site_units(soup, record, url)
    seen, rows = set(), []
    nodes = soup.select(UNIT_SELECTOR)
    # Broad fallback: panels with both a price and a unit size, without climbing
    # huge container nodes. These must be manually checked against actual pages.
    if not nodes:
        nodes = [n for n in soup.select('article, li, section')
                 if SIZE_RE.search(n.get_text(' ', strip=True)[:500])
                 and PRICE_RE.search(n.get_text(' ', strip=True)[:500])]
    for node in nodes:
        content = node.get_text(' ', strip=True)
        if not 5 <= len(content) <= 1000 or content in seen: continue
        match = SIZE_RE.search(content)
        if not match: continue
        seen.add(content)
        price = PRICE_RE.search(content)
        prices = PRICE_RE.findall(content)
        old = node.select_one('del, s, [class*="original-price"], [class*="was-price"]')
        standard = PRICE_RE.search(old.get_text(' ', strip=True)) if old else None
        current = [v for v in prices if not standard or v != standard.group()]
        period = re.search(r'\b(per\s+|/\s*)?(week|month|4 weeks|fortnight)\b', content, re.I)
        dimensions = re.search(r'\d+(?:\.\d+)?\s*m?\s*[x×]\s*\d+(?:\.\d+)?\s*m', content, re.I)
        offer = re.search(r'\b(?:\d+%\s*off|first\s+month[^,.]*|discount[^,.]*|special[^,.]*)', content, re.I)
        availability = ('unavailable' if re.search(r'not available|sold out|unavailable',content,re.I)
                        else 'available' if re.search(r'available',content,re.I) else 'unknown')
        rows.append({'scraped_at':datetime.now(timezone.utc).isoformat(),
                     **{k:record.get(k,'') for k in ['store_id','store_name','address','city','state','postcode','nearest_kss_site','nearest_kss_km']},
                     'centre_url':url,'size_m2':match.group(1),
                     'price_text':price.group() if price else '', 'availability':availability,
                     'standard_price':standard.group() if standard else '',
                     'advertised_price':current[0] if len(set(current)) == 1 else '',
                     'billing_period':period.group() if period else '',
                     'dimensions':dimensions.group() if dimensions else '',
                     'promotion':offer.group()[:120] if offer else '', 'unit_text':content})
    return rows


def inventory_state(soup, rows):
    if rows:
        return 'public_units_partial', 'Public facility cards only; all-unit route not requested. No stock count or booking verified.'
    tab=soup.select_one('[data-tab="tab--search"]')
    text=tab.get_text(' ',strip=True) if tab else ''
    if 'currently closed for major upgrades' in text.lower() and 'unavailable for bookings' in text.lower():
        return 'temporarily_closed', text
    if "this centre isn't available to be booked online" in text.lower():
        return 'contact_centre_no_online_units', text
    return 'no_units_in_html', 'No recognised units; inventory not established'


def main():
    parser=argparse.ArgumentParser(description='Scrape permitted public National Storage listings from an existing CSV.')
    parser.add_argument('--input',default='cannot_scrape.csv',help='Original CSV supplied by user')
    parser.add_argument('--limit',type=int,default=5,help='Sites to attempt (default 5; use 0 for all)')
    parser.add_argument('--delay',type=float,default=4.0,help='Wait at least this many seconds between requests')
    parser.add_argument('--output',default='national_storage_units.csv')
    parser.add_argument('--status',default='national_storage_status.csv')
    parser.add_argument('--save-html',help='Directory for permitted HTTP 200 facility HTML evidence; does not save block pages')
    parser.add_argument('--url-map',help='Reviewed CSV mapping store_id to centre_url; only fills missing/invalid facility URLs')
    args=parser.parse_args()
    source=locate_csv(args.input)
    print('Reading:',source,flush=True)
    with source.open('r',encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f)
        required={'brand','web_page','store_id','country'}
        if not required.issubset(set(reader.fieldnames or [])):
            sys.exit(f'ERROR: Expected columns {sorted(required)}, found {reader.fieldnames}')
        national=[r for r in reader if r.get('brand','').strip().casefold()=='national storage']
    print(f'National Storage facilities in CSV: {len(national)}',flush=True)
    url_map = {}
    if args.url_map:
        with Path(args.url_map).open(encoding='utf-8-sig',newline='') as mapping:
            for entry in csv.DictReader(mapping):
                store_id=entry.get('store_id','')
                mapped=centre_url(entry.get('centre_url',''))
                if not store_id or not mapped or store_id in url_map:
                    parser.error('URL map contains an invalid or duplicate mapping')
                url_map[store_id]=mapped
        if not set(url_map).issubset({r['store_id'] for r in national}):
            parser.error('URL map references a store ID outside the selected source')
    if args.limit > 0: national=national[:args.limit]
    if args.limit < 0 or args.delay < 0:
        parser.error('limit and delay must be nonnegative')
    session=requests.Session()
    session.headers.update({'User-Agent':'NationalStorageResearch/1.0', 'Accept-Language':'en-AU,en;q=0.9'})
    robot, robots_evidence = check_robots(session)
    robots_error = robots_evidence['status'] != 'verified'
    blocked = False
    facility_requests = 0
    units_total = 0
    outpath=Path(args.output).expanduser()
    statuspath=Path(args.status).expanduser()
    with outpath.open('w',encoding='utf-8-sig',newline='') as out, statuspath.open('w',encoding='utf-8-sig',newline='') as sf:
        writer=csv.DictWriter(out,fieldnames=COLUMNS);writer.writeheader()
        statuses=csv.DictWriter(sf,fieldnames=STATUS_COLUMNS);statuses.writeheader()
        for index, rec in enumerate(national,1):
            url=centre_url(rec.get('web_page','')) or url_map.get(rec.get('store_id',''),'')
            status={'scraped_at':datetime.now(timezone.utc).isoformat(),'store_id':rec.get('store_id',''),
                    'store_name':rec.get('store_name',''),'centre_url':url,'http_status':'',
                    'status':'','units_found':0,'details':'',
                    'country':rec.get('country',''), 'original_url':rec.get('web_page',''),
                    'facility_request_attempted':False,
                    'robots_http_status':robots_evidence['http_status'],
                    'robots_status':robots_evidence['status'], 'inventory_coverage':'unverified'}
            print(f'[{index}/{len(national)}] {rec.get("store_id", "")}  {url or "NO FACILITY URL"}',flush=True)
            if rec.get('country','').strip().upper() != 'AU':
                status.update(status='outside_australia',details='Source record is not AU; original URL: '+rec.get('web_page',''))
            elif not url and not rec.get('web_page','').strip():
                status.update(status='missing_url',details='No URL in source CSV')
            elif not url:
                status.update(status='invalid_facility_url',details='Not an Australian facility URL: '+rec.get('web_page',''))
            elif robots_error:
                status.update(status='robots_'+robots_evidence['status'],
                              details=robots_evidence['details'])
            elif blocked:
                status.update(status='not_attempted_after_block',details='Earlier access restriction; no further requests')
            elif not robot.can_fetch(url,session.headers['User-Agent']):
                status.update(status='robots_disallow',details='Facility page disallowed by robots.txt')
            else:
                # Honour an advertised crawl delay even if --delay is lower.
                crawl_delay = robot.crawl_delay(session.headers['User-Agent']) or 0
                request_rate = robot.request_rate(session.headers['User-Agent'])
                rate_delay = request_rate.seconds / request_rate.requests if request_rate and request_rate.requests else 0
                time.sleep(max(args.delay,crawl_delay,rate_delay)+random.uniform(0,0.4))
                try:
                    status['facility_request_attempted'] = True
                    facility_requests += 1
                    res=session.get(url,timeout=35,allow_redirects=False)
                    status['http_status']=res.status_code
                    body=res.text
                    problem = access_problem(res)
                    if problem:
                        status.update(status=problem,details='Access restriction or service failure; further facility requests stopped')
                        blocked = True
                    elif res.status_code!=200:
                        status.update(status='http_error',details=f'HTTP {res.status_code}')
                    else:
                        if args.save_html:
                            directory=Path(args.save_html)
                            directory.mkdir(parents=True,exist_ok=True)
                            (directory/(urlparse(url).path.strip('/').split('/')[-1]+'.html')).write_text(body,encoding='utf-8')
                        soup=BeautifulSoup(body,'html.parser')
                        status['facility_name']=page_facility_name(soup)
                        all_link=soup.select_one('a.js-fancy-unit-search[href]')
                        all_url=urljoin(url,all_link['href']) if all_link else ''
                        status['all_units_url']=all_url
                        status['all_units_access']=('robots_disallow' if not robot.can_fetch(all_url,session.headers['User-Agent']) else 'not_requested') if all_url else 'no_link_in_html'
                        status['unit_cards_in_html']=len(soup.select('.unit-details'))
                        units=scrape_units(body,rec,url)
                        writer.writerows(units)
                        units_total += len(units)
                        outcome,details=inventory_state(soup,units)
                        status.update(status=outcome,units_found=len(units),
                                      inventory_coverage='partial_facility_page' if units else 'unverified',
                                      details=details)
                        if status['unit_cards_in_html'] > len(units):
                            status.update(status='parse_mismatch',details='Fewer extracted rows than unit cards; inspect saved HTML')
                except requests.RequestException as exc:
                    status.update(status='request_error',details=f'{type(exc).__name__}: facility request failed')
                    blocked = True
            statuses.writerow(status);sf.flush();out.flush()
            print('   ->',status['status'],'units:',status['units_found'],flush=True)
            if status['facility_request_attempted'] and blocked:
                print('Stopping requests; remaining CSV statuses will be saved. No inventory inferred.',flush=True)
    with statuspath.open(encoding='utf-8-sig',newline='') as f:
        from collections import Counter
        outcomes=Counter(r['status'] for r in csv.DictReader(f))
    summary={'target_count':len(national),'statuses':dict(outcomes),
             'robots_check':robots_evidence, 'facility_requests':facility_requests,
             'units_extracted':units_total, 'verified_complete_facilities':0,
             'live_inventory_completeness':'unverified'}
    statuspath.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
    print('Saved:',outpath.resolve(), 'and',statuspath.resolve(),flush=True)
    session.close()
    # Partial data and successful CSV writing do not establish readiness.
    return 2 if robots_error or blocked or any(k != 'outside_australia' for k in outcomes) else 0

if __name__=='__main__':
    sys.exit(main())
