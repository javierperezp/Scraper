"""Audit identity, money and coverage consistency of a multi-brand run (offline)."""
import argparse
import csv
import json
from collections import Counter
from decimal import Decimal
from pathlib import Path


def read(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def audit(source, directory):
    source, directory = Path(source), Path(directory)
    inputs = read(source)
    statuses = read(directory/'store_status.csv')
    offers = read(directory/'offers.csv')
    daily = read(directory/'competitor_daily.csv')
    coverage = json.loads((directory/'coverage.json').read_text(encoding='utf-8'))
    expected = {r['store_id']: r for r in inputs}
    assert len(expected) == len(inputs), 'Duplicate source IDs'
    assert len(statuses) == len(inputs), 'Status coverage does not match input'
    assert {r['store_id'] for r in statuses} == set(expected), 'Status IDs differ from source'
    assert len({r['offer_id'] for r in offers}) == len(offers), 'Duplicate offer IDs'
    counts = Counter(r['store_id'] for r in offers)
    for status in statuses:
        assert counts[status['store_id']] == int(status['offers_found']), 'Offer/status count mismatch'
        assert status['brand'] == expected[status['store_id']]['brand'], 'Brand changed'
        assert status['original_url'] == expected[status['store_id']]['website'], 'Source URL changed'
        if status['status'] != 'public_units_partial':
            assert not int(status['offers_found']), 'Failure status has offers'
    for offer in offers:
        record = expected[offer['store_id']]
        assert offer['country'] == record['country'], 'Wrong country'
        assert offer['captured_at'] and offer['source_url'], 'Missing provenance'
        for name in ('regular_price_inc_gst', 'online_price_inc_gst'):
            if offer[name]:
                assert Decimal(offer[name]) >= 0 and offer['gst_basis'] != 'unknown', 'Unverified GST amount'
        if offer['promo_pct']:
            assert 0 <= Decimal(offer['promo_pct']) <= 100, 'Invalid discount'
        if offer['promo_months']:
            assert Decimal(offer['promo_months']) > 0, 'Invalid promotion duration'
    assert coverage['status_counts'] == dict(Counter(s['status'] for s in statuses)), 'Coverage status mismatch'
    assert coverage['input_stores'] == len(inputs) and coverage['offers'] == len(offers), 'Coverage totals mismatch'
    assert coverage['stores_with_offers'] == len(counts), 'Store count mismatch'
    assert coverage['daily_schema_rows'] == len(daily), 'Daily rows mismatch'
    assert len(daily) + sum(coverage['daily_schema_exclusions'].values()) == len(offers), 'Daily exclusions mismatch'
    for row in daily:
        candidates = [o for o in offers if o['store_id'] == row['competitor_store_id'] and o['source_url'] == row['url']
                      and o['size_m2'] == row['size_m2'] and o['online_price_inc_gst'] == row['online_price_inc_gst']
                      and o['regular_price_inc_gst'] == row['regular_price_inc_gst']]
        assert any(o['billing_period'] == 'month' and o['price_qualifier'] == 'advertised' for o in candidates), 'Noncomparable daily row'
    return {k: coverage[k] for k in ('input_stores', 'brands', 'stores_with_offers', 'offers', 'daily_schema_rows', 'status_counts')}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', default='competitors_missing_2026-10-20.csv')
    parser.add_argument('--output-dir', default='competitor_results')
    args = parser.parse_args()
    print(json.dumps(audit(args.input, args.output_dir), indent=2))
    print('Identity, prices and coverage checks passed.')
