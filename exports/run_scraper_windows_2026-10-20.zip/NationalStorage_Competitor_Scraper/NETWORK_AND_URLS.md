# Network diagnosis and missing-URL research

## What was tested

The existing cloud HTTPS proxy was preserved and TLS certificate verification
remained enabled. `curl_cffi==0.14.0` was installed in a temporary diagnostic
environment and tested with `impersonate="chrome"`:

| Destination | Observed result |
| --- | --- |
| `nationalstorage.com.au/robots.txt` | HTTP 200 |
| `storelocal.com.au/robots.txt` | Proxy CONNECT rejected, response 403 |
| `api.openstreetmap.org/robots.txt` | Proxy CONNECT rejected, response 403 |

Ordinary Python requests also received `ProxyError` for StoreLocal and OSM.
The detailed safe diagnostics are in `url_research/transport_probe.json`.
These are network-proxy denials before the destination's TLS handshake, so a
different browser fingerprint cannot activate the cloud domain allowlist. There
is no observed Cloudflare/Turnstile challenge to solve in these failures.

The tool available here can **save a configuration draft**, but cannot publish
that configuration or change this running instance's network policy. In
environment settings, review/save and publish the draft. It preserves the
existing pricing domains and adds `api.openstreetmap.org` for public business
metadata and `www.workstore.co.nz` from the supplied reference CSV. Publication
and subsequent access remain unverified. External proxies, CAPTCHA services and
stealth do not replace activating the intended environment policy.

An ordinary robots-aware National Storage directory check was also attempted.
`/locations/` redirected to `/locations-new/questionnaire/`, returning HTTP 200
without usable location links or geographic metadata. No questionnaire was
submitted, and no sitemap was fetched. The result is recorded in
`url_research/official_directory_check.json`.

## Missing URLs: measured results

All 45 previously unresolved records were cross-checked against the current
402-store input and 260 distinct facility URLs in the supplied 19 October CSV.
The uploaded files were not modified. This recovered **one URL by matching a
numbered address and brand**, leaving **44 facility URLs unresolved**:

| Research status | Records | Treatment |
| --- | ---: | --- |
| Smart Storage World: matched supplied brand/address | 1 | Mapped to the already supplied `https://smartstorageworld.com.au/book-online/`. |
| Company website leads | 8 | Brand homepages retained as leads; no facility prices attributed. |
| Possible operator change at the same address | 1 | Fort Knox / Loxon Nambour requires review. |
| Generic/unnamed map features | 15 | Need facility identity from their exact OSM objects. |
| Further public research needed | 20 | No defensible facility URL in supplied evidence. |

The Smart Storage World match is **33 Keilor Park Drive**, source record
`AU-77976`, missing record `AU-OSM-n10102587425`. The two supplied coordinates are
about 2.2 km apart. The address and brand match supports the URL, but the
geocoding discrepancy stays flagged and the website has not been live-verified.
Neither coordinates nor original brand/store identifiers were changed.

The missing Fort Knox record at **26 Jose Street, Nambour** is about four metres
from the supplied Loxon Nambour record at **26 Jose St**. Its candidate URL is
`https://loxonstorage.com.au/facility/nambour/`. This is a potential rebrand/data
conflict, so it was not automatically assigned as a Fort Knox website.

`url_research/missing_url_research.csv` contains every record, candidate URLs,
source IDs, matching reasons, coordinate warnings and exact OSM metadata URLs.
`url_research/updated_url_map.csv` combines the earlier six reviewed corrections
with the one newly matched URL. Company homepages and guessed domains are not
inserted as verified facility URLs.

## Continue after network access is enabled

The new resolver can retrieve public metadata for the **exact node/way/relation
IDs already in the input**, including `website` and `contact:website` tags. It
uses the same verified-TLS, robots-aware, throttled transport as the scraper.
It stops requests to OSM after a network/access failure and can reuse saved
metadata with hash checks. It does not use sitemaps or infer that the nearest
storage facility is the same business.

Run from the extracted package folder:

```powershell
py -m pip install -r requirements.txt
py resolve_competitor_urls.py --input competitors_missing_2026-10-20.csv --url-map reviewed_facility_urls.csv --history url_research/supplied_historical_facilities.csv --lookup-osm --output-dir url_research_local
py competitor_scraper.py --input competitors_missing_2026-10-20.csv --url-map url_research_local/updated_url_map.csv --output-dir competitor_results_new
```

OSM may itself lack contact websites; its tags still need facility verification.
The metadata lookup's live attempt was blocked at the OSM robots request; the
remaining 44 records were marked paused without repeating failed requests. This
did not retrieve new OSM website data.

To retry the currently mapped pricing destinations after the cloud policy is
published, the included checkpoint is ready:

```powershell
py competitor_scraper.py --input competitors_missing_2026-10-20.csv --url-map url_research/updated_url_map.csv --output-dir competitor_results_2026-10-20_updated --resume --retry-failed
```

A changed URL map needs a new output directory. Any website-specific restriction
that remains after network access is restored will be recorded separately;
supported JavaScript/API adapters still require real-page validation.

## Updated outputs and validation

`competitor_results_2026-10-20_updated/` retains the original **290 listings from
97 National Storage stores**, with their original capture times. Its 402 statuses
now include **44 missing URLs**, **256 network-affected records**, four
contact-only stores and one temporarily closed store. The newly mapped Smart
Storage World record was paused based on the existing failure for its exact
source URL; no new pricing request was made. **No additional prices were scraped
in this follow-up.**

The price CSV is byte-identical to the previous delivery. All 88 tests pass,
including address/country/brand conflicts, OSM identity and lifecycle checks,
metadata integrity, JSON content types and robots enforcement. OSM tests are
controlled fixtures, not a claim of successful live OSM access.

```powershell
py -m pytest -q
py validate_competitor_results.py --output-dir competitor_results_2026-10-20_updated
```
