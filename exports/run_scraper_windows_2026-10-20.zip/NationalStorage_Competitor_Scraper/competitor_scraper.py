"""Scrape permitted public storage pricing for every record in the supplied CSV.

Windows: py competitor_scraper.py --input competitors_missing_2026-10-20.csv
See COMPETITOR_SCRAPER.md for output contracts, resume and coverage limitations.
"""
import argparse
import csv
import hashlib
import json
import sqlite3
import sys
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from urllib.parse import urlparse
from zoneinfo import ZoneInfo
import threading

from bs4 import BeautifulSoup

from competitor_access import AccessFailure, PublicClient, public_url, publisher, timestamp, unit_links
from competitor_extract import parse_page
from export_competitor_daily import COLUMNS as DAILY_COLUMNS, access_code, normalized, size_band, subject_lookup, unit_dimensions

VERSION = '2.0'
OFFER_COLUMNS = ['captured_at', 'store_id', 'brand', 'store_name', 'address', 'city', 'state', 'postcode', 'country',
                 'lat', 'lng', 'nearest_kss_site', 'nearest_kss_km', 'offer_id', 'unit_id', 'unit_type', 'unit_label',
                 'size_m2', 'dimensions', 'features', 'regular_price_advertised', 'online_price_advertised',
                 'regular_price_inc_gst', 'online_price_inc_gst', 'gst_basis', 'currency', 'billing_period',
                 'price_qualifier', 'promo_text', 'promo_pct', 'promo_months', 'availability',
                 'availability_evidence', 'inventory_coverage', 'source_url', 'adapter', 'evidence_text']
PROMO_COLUMNS = ['captured_at', 'store_id', 'brand', 'store_name', 'source_url', 'promo_text', 'promo_pct', 'promo_months', 'eligibility']
STATUS_COLUMNS = ['store_id', 'brand', 'store_name', 'country', 'original_url', 'effective_url', 'status', 'offers_found',
                  'promotions_found', 'checked_at', 'captured_at', 'http_status', 'details', 'warnings',
                  'platforms', 'links_checked', 'evidence_mode', 'inventory_coverage']
NO_RETRY = {'missing_url', 'invalid_url', 'temporarily_closed', 'contact_centre_no_online_units'}


def read_csv(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def load_records(path, url_map=None):
    rows = read_csv(path)
    required = {'store_id', 'brand', 'store_name', 'country', 'website'}
    if not rows or not required.issubset(rows[0]):
        raise ValueError('Input must contain records and columns: ' + ', '.join(sorted(required)))
    ids = [r['store_id'].strip() for r in rows]
    if any(not value for value in ids) or len(set(ids)) != len(ids):
        raise ValueError('Every store_id must be present and unique')
    overrides = {}
    if url_map:
        for row in read_csv(url_map):
            key, url = row.get('store_id', ''), row.get('website', row.get('centre_url', ''))
            if key not in ids or key in overrides or not public_url(url):
                raise ValueError('URL map must contain unique source store IDs and valid public URLs')
            overrides[key] = public_url(url)
    for row in rows:
        row['store_id'] = row['store_id'].strip()
        row['country'] = row['country'].strip().upper()
        row['_url'] = overrides.get(row['store_id'], public_url(row['website']))
    counts = Counter(r['_url'].rstrip('/') for r in rows if r['_url'])
    brand_counts = Counter(r['brand'].casefold() for r in rows)
    for row in rows:
        homepage = urlparse(row['_url']).path in ('', '/')
        row['_needs_location'] = bool(row['_url'] and (counts[row['_url'].rstrip('/')] > 1 or homepage and brand_counts[row['brand'].casefold()] > 1))
    return rows


def location_matches(html, record):
    """Require a facility address on shared/homepage URLs before assigning rates."""
    soup = BeautifulSoup(html, 'html.parser')
    expected = normalized(record.get('address', ''))
    # Normalize road suffixes for textual address matching, require number+street.
    def address_words(value):
        value = normalized(value)
        import re
        value = re.sub(r'\b(street|road|avenue|drive|court)\b', lambda m: {'street':'st','road':'rd','avenue':'ave','drive':'dr','court':'ct'}[m.group()], value)
        return re.sub(r'[^a-z0-9]', '', value)
    if not expected or not any(c.isdigit() for c in expected):
        return False
    needle = address_words(expected)
    addresses = []
    for script in soup.select('script[type="application/ld+json"]'):
        try:
            data = json.loads(script.string or script.get_text())
        except (ValueError, TypeError):
            continue
        from competitor_extract import json_nodes
        for node in json_nodes(data):
            address = node.get('address', {})
            if isinstance(address, dict) and address.get('streetAddress'):
                addresses.append(address_words(str(address['streetAddress'])))
    # Multi-address pages still do not establish which units belong to which store.
    return len(set(addresses)) == 1 and needle == addresses[0]


class ReplayClient:
    """Replay only cache records with a hash, original timestamp and access proof."""
    def __init__(self, directory):
        self.pages = {}
        for path in Path(directory).glob('*.json'):
            meta = json.loads(path.read_text(encoding='utf-8'))
            if 'url' not in meta or not path.with_suffix('.html').is_file():
                continue
            raw = path.with_suffix('.html').read_bytes()
            if hashlib.sha256(raw).hexdigest() != meta.get('sha256'):
                raise ValueError('Cache integrity check failed: ' + path.name)
            if meta.get('robots', {}).get('status') not in ('verified', 'absent') or not meta.get('captured_at'):
                raise ValueError('Cache has no original timestamp or public-access evidence: ' + path.name)
            page = (raw.decode(meta.get('encoding', 'utf-8')), meta['url'], meta['captured_at'], meta)
            for url in (meta['url'], meta.get('requested_url', meta['url'])):
                if url not in self.pages or self.pages[url][2] < meta['captured_at']:
                    self.pages[url] = page

    def fetch(self, url):
        if url not in self.pages:
            raise AccessFailure('not_in_replay_cache', 'No saved permitted page for this exact URL; no network request made')
        return self.pages[url]


def initial_status(record, mode):
    return dict(store_id=record['store_id'], brand=record['brand'], store_name=record['store_name'], country=record['country'],
                original_url=record['website'], effective_url=record['_url'], status='pending', offers_found=0,
                promotions_found=0, checked_at='', captured_at='', http_status='', details='', warnings='',
                platforms='', links_checked='[]', evidence_mode=mode, inventory_coverage='unverified')


def collect(record, client, max_pages=3, mode='live'):
    status = initial_status(record, mode)
    status['checked_at'] = timestamp()
    offers, promos, warnings, platforms, checked = {}, {}, [], set(), []
    if not record['_url']:
        status.update(status='missing_url' if not record['website'].strip() else 'invalid_url',
                      details='No usable public URL supplied; no discovery or sitemap requested')
        return {'status': status, 'offers': [], 'promotions': []}
    queue, visited = [record['_url']], set()
    while queue and len(visited) < max_pages:
        url = queue.pop(0)
        if url in visited:
            continue
        visited.add(url)
        try:
            html, final, captured, evidence = client.fetch(url)
            checked.append({'url': url, 'final_url': final, 'status': 'fetched', 'sha256': evidence['sha256']})
            status.update(http_status=200, captured_at=captured, effective_url=final)
            redirected_away = urlparse(final).path.rstrip('/').lower() != urlparse(url).path.rstrip('/').lower()
            if (record['_needs_location'] or redirected_away or publisher(final) != publisher(record['_url'])) and not location_matches(html, record):
                status.update(status='location_context_unverified', details='Shared/multi-store page has no unique matching facility address; prices were not assigned')
                break
            rows, promotions, info = parse_page(html, record, final, captured)
            warnings.extend(info['warnings'])
            platforms.update(info['platforms'])
            for row in rows:
                offers.setdefault(row['offer_id'], row)
            for promo in promotions:
                promos.setdefault((promo['source_url'], promo['promo_text']), promo)
            status.update(status=info['status'], details=info['note'])
            for link in unit_links(html, final, record):
                if link not in visited and link not in queue:
                    queue.append(link)
        except AccessFailure as failure:
            checked.append({'url': url, 'status': failure.status, 'details': failure.detail})
            if len(visited) == 1:
                status.update(status=failure.status, details=failure.detail, http_status=failure.http_status)
            else:
                warnings.append(f'{failure.status}: additional public unit page unavailable')
            if failure.status in ('cloudflare_or_access_block', 'authentication_required', 'access_denied', 'rate_limited',
                                   'service_unavailable', 'network_error', 'network_proxy_error', 'network_policy_denied', 'publisher_paused'):
                break
        except Exception as exc:
            # Persist other records and make parser defects visible without exposing tokens.
            status.update(status='parser_error', details=f'{type(exc).__name__}: inspect cached HTML and run tests')
            warnings.append('Unexpected parser failure; this facility needs review')
            break
    if queue:
        warnings.append(f'{len(queue)} candidate link(s) not followed; page limit or access stop')
    if offers:
        status.update(status='public_units_partial', details='Advertised public rates only; complete inventory and live stock are not established', inventory_coverage='partial_public_pages')
    status.update(offers_found=len(offers), promotions_found=len(promos), warnings='; '.join(dict.fromkeys(warnings)),
                  platforms='; '.join(sorted(platforms)), links_checked=json.dumps(checked))
    return {'status': status, 'offers': list(offers.values()), 'promotions': list(promos.values())}


def write_csv(path, fields, rows):
    path = Path(path)
    temp = path.with_suffix(path.suffix + '.tmp')
    with temp.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    temp.replace(path)


def daily_offer(offer, subjects):
    # The historical 35-column schema has no currency, tax basis, period or
    # "from price" flag, so keep unverified/noncomparable rates in offers.csv.
    if offer['billing_period'] != 'month':
        return None, 'nonmonthly_or_unknown_billing_period'
    if offer['price_qualifier'] != 'advertised':
        return None, 'from_price'
    if not offer['online_price_advertised']:
        return None, 'missing_price'
    if not offer['online_price_inc_gst']:
        return None, 'unknown_tax_basis'
    expected = {'AU': 'AUD', 'NZ': 'NZD'}.get(offer['country'])
    if not expected or offer['currency'] != expected:
        return None, 'currency_mismatch'
    area = Decimal(offer['size_m2'] or '0')
    if area <= 0:
        return None, 'unknown_unit_area'
    local = datetime.fromisoformat(offer['captured_at']).astimezone(ZoneInfo('Pacific/Auckland' if offer['country'] == 'NZ' else 'Australia/Sydney')).date()
    ending = local + timedelta(days=(6-local.weekday()) % 7)
    row = {key: '' for key in DAILY_COLUMNS}
    row.update(week_ending=ending.isoformat(), captured_on=local.isoformat(), source='scraper', country=offer['country'],
               subject_store_id=subjects.get((offer['country'], normalized(offer['nearest_kss_site'])), ''),
               subject_store_name=offer['nearest_kss_site'], is_subject='0', competitor_store_id=offer['store_id'],
               brand=offer['brand'], store_name=offer['store_name'], address=offer['address'], city=offer['city'],
               state=offer['state'], postcode=offer['postcode'], lat=offer['lat'], lng=offer['lng'], proximity=offer['nearest_kss_km'],
               unit_type='Unit' if offer['unit_type'] == 'storage unit' else offer['unit_type'],
               unit_size=unit_dimensions(offer['dimensions']), size_m2=offer['size_m2'], size_band=size_band(offer['size_m2']),
               access=access_code(offer['features']), unit_features=offer['features'],
               regular_price_inc_gst=offer['regular_price_inc_gst'], online_price_inc_gst=offer['online_price_inc_gst'],
               price_per_m2_inc_gst=format((Decimal(offer['regular_price_inc_gst']) / area).quantize(Decimal('.01'), rounding=ROUND_HALF_UP), 'f') if offer['regular_price_inc_gst'] else '',
               promo_text=offer['promo_text'], promo_pct=offer['promo_pct'], promo_months=offer['promo_months'],
               promo_parsed='1' if offer['promo_pct'] and offer['promo_months'] else '0', url=offer['source_url'])
    return row, ''


def snapshot(directory, records, results, subjects, mode):
    statuses, offers, promos, daily = [], [], [], []
    exclusions = Counter()
    for record in records:
        result = results.get(record['store_id'], {'status': initial_status(record, mode), 'offers': [], 'promotions': []})
        statuses.append(result['status'])
        offers.extend(result['offers'])
        promos.extend(result['promotions'])
    for offer in offers:
        row, reason = daily_offer(offer, subjects)
        if row:
            daily.append(row)
        else:
            exclusions[reason] += 1
    write_csv(directory / 'offers.csv', OFFER_COLUMNS, offers)
    write_csv(directory / 'promotions.csv', PROMO_COLUMNS, promos)
    write_csv(directory / 'store_status.csv', STATUS_COLUMNS, statuses)
    write_csv(directory / 'competitor_daily.csv', DAILY_COLUMNS, daily)
    brands = []
    for brand in sorted({r['brand'] for r in records}, key=str.casefold):
        selected = [s for s in statuses if s['brand'] == brand]
        brands.append({'brand': brand, 'input_stores': len(selected),
                       'stores_with_offers': sum(s['offers_found'] > 0 for s in selected),
                       'offers': sum(s['offers_found'] for s in selected),
                       'missing_urls': sum(s['status'] == 'missing_url' for s in selected),
                       'pending': sum(s['status'] == 'pending' for s in selected),
                       'statuses': dict(Counter(s['status'] for s in selected))})
    write_csv(directory / 'brand_coverage.csv', ['brand', 'input_stores', 'stores_with_offers', 'offers', 'missing_urls', 'pending'], brands)
    report = {'script_version': VERSION, 'generated_at': timestamp(), 'evidence_mode': mode,
              'input_stores': len(records), 'brands': len(brands), 'countries': dict(Counter(r['country'] for r in records)),
              'stores_with_offers': sum(s['offers_found'] > 0 for s in statuses), 'offers': len(offers),
              'priced_offers': sum(bool(o['online_price_advertised'] or o['regular_price_advertised']) for o in offers),
              'stores_with_prices': len({o['store_id'] for o in offers if o['online_price_advertised'] or o['regular_price_advertised']}),
              'daily_schema_rows': len(daily), 'daily_schema_exclusions': dict(exclusions),
              'status_counts': dict(Counter(s['status'] for s in statuses)),
              'adapter_counts': dict(Counter(o['adapter'] for o in offers)), 'by_brand': brands,
              'complete_inventory_verified': False,
              'notes': ['No sitemap discovery, logins, CAPTCHAs, stealth, proxy rotation or restriction bypass.',
                        'A missing or unsupported price is not evidence of zero units.',
                        'Historical/replayed captures keep original timestamps; checked_at is the current audit time.',
                        'GST-inclusive fields stay blank when tax basis is unknown; advertised amounts remain in offers.csv.',
                        'Daily schema contains only exact monthly prices with a known GST basis and local currency.']}
    temp = directory / 'coverage.json.tmp'
    temp.write_text(json.dumps(report, indent=2), encoding='utf-8')
    temp.replace(directory / 'coverage.json')
    return report


class Checkpoint:
    def __init__(self, path, identity, resume):
        existed = path.exists()
        if existed and not resume:
            raise ValueError('Output already has a checkpoint. Use --resume or choose a new --output-dir.')
        self.db = sqlite3.connect(path)
        self.db.execute('CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)')
        self.db.execute('CREATE TABLE IF NOT EXISTS results (store_id TEXT PRIMARY KEY, payload TEXT NOT NULL)')
        previous = dict(self.db.execute('SELECT key,value FROM metadata'))
        if previous and previous.get('identity') != identity:
            self.db.close()
            raise ValueError('Input/URL mapping differs from the checkpoint. Use a new output directory.')
        self.db.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)', ('identity', identity))
        self.db.commit()

    def read(self):
        return {key: json.loads(payload) for key, payload in self.db.execute('SELECT store_id,payload FROM results')}

    def save(self, result):
        self.db.execute('INSERT OR REPLACE INTO results VALUES (?,?)', (result['status']['store_id'], json.dumps(result)))
        self.db.commit()

    def close(self):
        self.db.close()


def main(argv=None, live_client=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', default='competitors_missing_2026-10-20.csv')
    parser.add_argument('--output-dir', default='competitor_results')
    parser.add_argument('--url-map', help='Reviewed CSV: store_id,website (centre_url also accepted)')
    parser.add_argument('--subject-lookup', default='subject_store_lookup.csv')
    parser.add_argument('--delay', type=float, default=4, help='Minimum interval per publisher; robots may increase it')
    parser.add_argument('--timeout', type=float, default=25)
    parser.add_argument('--workers', type=int, default=4, help='Parallel publishers, not parallel requests to one publisher')
    parser.add_argument('--max-pages', type=int, default=3, help='Initial facility plus explicit public unit/pricing links')
    parser.add_argument('--limit', type=int, default=0, help='Maximum stores with URLs; 0 means all. Other rows remain visible.')
    parser.add_argument('--brand', action='append', help='Optional exact brand selection; repeatable')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--retry-failed', action='store_true', help='With --resume, retry failed/unsupported stores')
    parser.add_argument('--replay-cache', help='Network-free re-extraction from this scraper\'s permitted HTML cache')
    args = parser.parse_args(argv)
    if args.delay < 0 or args.timeout <= 0 or not 1 <= args.workers <= 8 or not 1 <= args.max_pages <= 10 or args.limit < 0:
        parser.error('Invalid delay, timeout, workers (1..8), pages (1..10) or limit')
    if args.retry_failed and not args.resume:
        parser.error('--retry-failed requires --resume')
    directory = Path(args.output_dir)
    directory.mkdir(parents=True, exist_ok=True)
    mode = 'replay' if args.replay_cache else 'live'
    try:
        records = load_records(args.input, args.url_map)
        identity = hashlib.sha256(json.dumps([VERSION, mode, records], sort_keys=True).encode()).hexdigest()
        checkpoint = Checkpoint(directory / 'checkpoint.sqlite3', identity, args.resume)
        results = checkpoint.read()
        subjects = subject_lookup(read_csv(args.subject_lookup)) if Path(args.subject_lookup).is_file() else {}
        if args.replay_cache and live_client is not None:
            raise ValueError('A live transport cannot be supplied for offline replay')
        client = ReplayClient(args.replay_cache) if args.replay_cache else live_client or PublicClient(args.delay, args.timeout, directory / 'html_cache')
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    groups, selected = defaultdict(list), 0
    for record in records:
        old = results.get(record['store_id'])
        if old and (not args.retry_failed or old['status']['offers_found'] or old['status']['status'] in NO_RETRY):
            continue
        if args.brand and record['brand'].casefold() not in {b.casefold() for b in args.brand}:
            continue
        if not record['_url']:
            result = collect(record, client, args.max_pages, mode)
            checkpoint.save(result)
            results[record['store_id']] = result
            continue
        if args.limit and selected >= args.limit:
            continue
        selected += 1
        groups[publisher(record['_url'])].append(record)
    snapshot(directory, records, results, subjects, mode)
    print(f'{len(records)} stores, {len(set(r["brand"] for r in records))} brands; {selected} URL records scheduled ({mode}).', flush=True)
    # Workers return individual results through a thread-safe queue. Only the
    # main thread writes SQLite and atomic CSV snapshots.
    import queue
    messages = queue.Queue()
    stopped = threading.Event()
    def collect_group(group):
        for record in group:
            if stopped.is_set():
                break
            messages.put(collect(record, client, args.max_pages, mode))
    pool = ThreadPoolExecutor(max_workers=args.workers)
    try:
        futures = [pool.submit(collect_group, group) for group in groups.values()]
        remaining = selected
        while remaining:
            try:
                result = messages.get(timeout=.2)
            except queue.Empty:
                if all(f.done() for f in futures):
                    for future in futures:
                        future.result()  # Surface worker errors, do not silently hang.
                    if messages.empty():
                        break
                continue
            checkpoint.save(result)
            results[result['status']['store_id']] = result
            remaining -= 1
            status = result['status']
            print(f'{status["brand"]} | {status["store_name"]} | {status["status"]} | {status["offers_found"]} offers', flush=True)
            snapshot(directory, records, results, subjects, mode)
        for future in futures:
            future.result()
    finally:
        stopped.set()
        pool.shutdown(wait=True, cancel_futures=True)
        # Preserve a result that completed while an interrupt was being handled.
        while not messages.empty():
            result = messages.get_nowait()
            checkpoint.save(result)
            results[result['status']['store_id']] = result
        report = snapshot(directory, records, results, subjects, mode)
        checkpoint.close()
    print(json.dumps({k: report[k] for k in ('input_stores', 'stores_with_offers', 'offers', 'daily_schema_rows', 'status_counts')}, indent=2), flush=True)
    print('Saved CSVs and coverage.json to ' + str(directory.resolve()), flush=True)
    # 2 is a deliberate incomplete-coverage result, not a CSV-write failure.
    return 2 if any(s['status']['status'] != 'public_units_partial' for s in results.values()) or len(results) != len(records) else 0


if __name__ == '__main__':
    sys.exit(main())
