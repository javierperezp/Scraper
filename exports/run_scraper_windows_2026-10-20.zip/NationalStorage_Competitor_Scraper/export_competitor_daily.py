"""Export National Storage listings with GST-inclusive prices and explicit promos.

The original raw units/status CSVs are retained. National Storage's public terms
state advertised AU prices include 10% GST. Those advertised amounts are retained.
Temporary advertised sale prices populate online_price_inc_gst. Promotions are
represented as their percentage and stated valid months, without averaging.
"""
import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from zoneinfo import ZoneInfo

COLUMNS = [
    'week_ending', 'captured_on', 'source', 'country',
    'subject_store_id', 'subject_store_name', 'is_subject',
    'competitor_store_id', 'brand', 'store_name', 'address', 'city',
    'state', 'postcode', 'lat', 'lng', 'proximity',
    'store_storage_total_m2', 'store_storage_rentable_m2',
    'store_parking_total_m2', 'store_parking_rentable_m2',
    'unit_type', 'unit_size', 'size_m2', 'size_band', 'access', 'unit_features',
    'regular_price_inc_gst', 'online_price_inc_gst', 'price_per_m2_inc_gst',
    'promo_text', 'promo_pct', 'promo_months', 'promo_parsed',
    'url',
]
BANDS = [('1','0-1'),('3.5','1-3.5'),('7','3.5-7'),('11','7-11'),
         ('15','11-15'),('22','15-22'),('32','22-32'),('48','32-48'),
         ('68','48-68'),('100','68-100')]


def read(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def normalized(value):
    return ' '.join(value.split()).casefold()


def subject_lookup(rows):
    ids=defaultdict(set)
    for row in rows:
        if row.get('country') and row.get('subject_store_name') and row.get('subject_store_id'):
            ids[(row['country'].strip().upper(), normalized(row['subject_store_name']))].add(row['subject_store_id'])
    return {key:next(iter(values)) for key,values in ids.items() if len(values)==1}


def money(value):
    return format(value.quantize(Decimal('.01'), rounding=ROUND_HALF_UP), '.2f')


def size_band(value):
    area=Decimal(value)
    if area<=0:
        raise ValueError('Unit area must be positive')
    return next((label for upper,label in BANDS if area<=Decimal(upper)), '100+')


def unit_dimensions(value):
    match=re.fullmatch(r'\s*\(?\s*(\d+(?:\.\d+)?)\s*m?\s*[x×]\s*(\d+(?:\.\d+)?)\s*m\s*\)?\s*',value,re.I)
    return f'{match.group(1)}m x {match.group(2)}m' if match else value


def access_code(features):
    if re.search(r'\bdriveway\b|\bdrive[ -]?up\b',features,re.I):return 'DR'
    if re.search(r'\bupper level\b',features,re.I):return 'UP'
    if re.search(r'\bground floor\b',features,re.I):return 'GR'
    return ''


def promotion(row):
    text=row.get('promotion','')
    pct=re.search(r'(\d+(?:\.\d+)?)\s*%\s*off',text,re.I)
    months=re.search(r'\bfor\s+(\d+(?:\.\d+)?)\s+months?\b',row.get('promotion_duration',''),re.I)
    if pct and months and Decimal(pct.group(1))<=100 and Decimal(months.group(1))>0:
        return pct.group(1), months.group(1), True
    return '', '', False


def convert(row, source, subjects, timezone='Australia/Sydney'):
    if source['country'].strip().upper()!='AU' or normalized(source['brand'])!='national storage':
        raise ValueError('Only Australian National Storage records are supported')
    if row.get('billing_period')!='month':
        raise ValueError('Cannot map a non-monthly price to the monthly schema')
    captured=datetime.fromisoformat(row['scraped_at'])
    if captured.utcoffset() is None:
        raise ValueError('Collection timestamp must include a timezone')
    captured=captured.astimezone(ZoneInfo(timezone)).date()
    ending=captured+timedelta(days=(6-captured.weekday())%7)
    country=source['country'].strip().upper()
    area=Decimal(row['size_m2'])
    if area<=0:
        raise ValueError('Unit area must be positive')
    regular=Decimal(row['standard_price_aud'])
    online=Decimal(row['advertised_price_aud'])
    if regular<0 or online<0:
        raise ValueError('Unit prices must not be negative')
    pct,months,parsed=promotion(row)
    target={column:'' for column in COLUMNS}
    target.update(
        week_ending=ending.isoformat(),captured_on=captured.isoformat(),source='scraper',country=country,
        subject_store_id=subjects.get((country,normalized(source.get('nearest_kss_site',''))),''),
        subject_store_name=source.get('nearest_kss_site',''),is_subject='0',
        competitor_store_id=row['store_id'],brand='National Storage',
        store_name=row.get('facility_name') or row['store_name'],
        address=row.get('facility_address') or row.get('address',''),
        city=row.get('facility_city') or row.get('city',''),
        state=row.get('facility_state') or row.get('state',''),
        postcode=row.get('facility_postcode') or row.get('postcode',''),
        lat=source.get('lat',''),lng=source.get('lng',''),proximity=source.get('nearest_kss_km',''),
        unit_type='Unit' if row['unit_type']=='storage unit' else row['unit_type'],
        unit_size=unit_dimensions(row['dimensions']),size_m2=row['size_m2'],
        size_band=size_band(row['size_m2']),access=access_code(row.get('features','')),
        unit_features=row.get('features',''),
        regular_price_inc_gst=money(regular),
        online_price_inc_gst=money(online),
        # The reference file uses the regular price for price-per-area, also
        # when regular and online prices differ. Retain that convention.
        price_per_m2_inc_gst=money(regular/area),
        promo_text=f'{pct}% for {months} month'+('' if Decimal(months)==1 else 's') if parsed else row.get('promotion',''),
        promo_pct=pct,promo_months=months,promo_parsed='1' if parsed else '0',
        url=row.get('source_url') or row['centre_url'],
    )
    return target


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--units',default='national_storage_units.csv')
    parser.add_argument('--source',default='cannot_scrape.csv')
    parser.add_argument('--subjects',default='subject_store_lookup.csv')
    parser.add_argument('--schema',default='competitor_daily_schema.json')
    parser.add_argument('--output',default='national_storage_competitor_daily.csv')
    parser.add_argument('--timezone',default='Australia/Sydney')
    args=parser.parse_args()
    if json.loads(Path(args.schema).read_text())!=COLUMNS:
        parser.error('Requested schema does not match the supported 35-column GST-inclusive format')
    rows=read(args.units)
    sources={r['store_id']:r for r in read(args.source)}
    subjects=subject_lookup(read(args.subjects))
    output=[convert(row,sources[row['store_id']],subjects,timezone=args.timezone) for row in rows]
    destination=Path(args.output)
    protected={Path(p).resolve() for p in [args.units,args.source,args.subjects,args.schema]}
    if destination.resolve() in protected:
        parser.error('Output must not overwrite an input file')
    temporary=destination.with_suffix('.tmp.csv')
    with temporary.open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=COLUMNS)
        writer.writeheader();writer.writerows(output)
    temporary.replace(destination)
    unresolved=sorted({r['subject_store_name'] for r in output if not r['subject_store_id']})
    report={
        'output':destination.name,'columns':COLUMNS,'schema_column_count':len(COLUMNS),
        'input_listing_rows':len(rows),'output_rows':len(output),
        'stores':len({r['competitor_store_id'] for r in output}),
        'captured_on_counts':dict(Counter(r['captured_on'] for r in output)),
        'subject_id_matched_rows':sum(bool(r['subject_store_id']) for r in output),
        'subject_id_blank_rows':sum(not r['subject_store_id'] for r in output),
        'unresolved_subject_names':unresolved,
        'blank_store_area_metrics':'All four store-area metrics left blank; their definitions cannot be established from store_m2_stortrack',
        'gst_basis':{'advertised_prices':'inclusive','au_gst_percent':10,'official_source':'https://nationalstorage.com.au/terms-conditions/'},
        'price_basis':'GST-inclusive amounts copied as advertised; no tax conversion',
        'promotion_method':'Advertised promo percentage and valid months only; no averaged or effective price',
        'price_per_m2_method':'Standard GST-inclusive price / unit area',
        'online_price_method':'Actual advertised amount, including a temporary promotional price where present',
        'rounding':'Full-precision Decimal calculations, rounded once to cents using ROUND_HALF_UP',
        'timezone':args.timezone,
        'promotion_parsed_rows':sum(r['promo_parsed']=='1' for r in output),
        'schema_omissions':'Availability, inventory completeness, unit ID and raw evidence remain in the original units/status outputs; the supplied schema has no such columns',
        'scope':'Partial public facility-page listings only; restricted all-unit listings were not collected',
    }
    destination.with_suffix('.report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    return 0


if __name__=='__main__':
    raise SystemExit(main())
