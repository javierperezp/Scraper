import hashlib
import json
from pathlib import Path

import pytest

from competitor_access import AccessFailure
from resolve_competitor_urls import supplied_match, metadata_record, apply_osm, read_metadata_cache, osm_url, main
from test_competitor_scraper import FakeResponse, client_with


def target(**changes):
    return dict(store_id='AU-OSM-n123', brand='Test Storage',store_name='Test Storage',country='AU',
                address='33 Main Road',city='Town',lat='-37',lng='145',**changes)


def source(**changes):
    row=dict(store_id='AU-456',brand='Test Storage',country='AU',address='33 Main Rd',city='Town',
             lat='-37',lng='145',_url='https://storage.example/branch/')
    row.update(changes)
    return row


def test_supplied_address_and_brand_match_retains_coordinate_conflict():
    record=target()
    result=supplied_match(record,[source(lat='-37.02')])
    assert result['resolved_url']=='https://storage.example/branch/'
    assert result['resolution_status']=='matched_supplied_brand_and_address'
    assert 'Coordinate conflict' in result['notes']
    assert result['lat']==record['lat']


def test_nearby_different_address_does_not_become_facility_url():
    result=supplied_match(target(),[source(address='99 Other Street')])
    assert result['resolved_url']==''
    assert json.loads(result['candidate_urls'])==['https://storage.example/']
    assert result['resolution_status']=='brand_site_known_facility_unverified'


def test_rebrand_colocation_is_candidate_only():
    result=supplied_match(target(),[source(brand='Different Operator')])
    assert not result['resolved_url']
    assert result['resolution_status']=='same_address_different_brand_review'
    assert result['distance_m']==0


def test_country_and_conflicting_urls_require_review():
    assert not supplied_match(target(),[source(country='NZ')])['resolved_url']
    result=supplied_match(target(),[source(),source(_url='https://other.example/branch/')])
    assert result['resolution_status']=='conflicting_supplied_urls'
    assert not result['resolved_url']


def test_distinct_numbered_unit_addresses_are_not_collapsed():
    record=target();record['address']='1/23 Main Road'
    assert not supplied_match(record,[source(address='12/3 Main Rd')])['resolved_url']


def test_osm_exact_object_id_and_contact_website():
    payload={'elements':[{'type':'node','id':123,'user':'excluded editor','uid':1234,
        'tags':{'name':'Actual Store','contact:website':'https://actual.example/facility','addr:street':'Main Road'}}]}
    data=metadata_record(payload,'AU-OSM-n123','2026-10-20T00:00:00Z',{'status':'verified'},'body-hash')
    assert 'excluded editor' not in json.dumps(data)
    result=apply_osm(supplied_match(target(),[]),data)
    assert result['resolved_url']=='https://actual.example/facility'
    assert result['resolution_status']=='website_from_exact_osm_object'
    assert result['osm_current_name']=='Actual Store'
    with pytest.raises(ValueError,match='requested object'):
        metadata_record(payload,'AU-OSM-n456','now',{'status':'verified'},'hash')


@pytest.mark.parametrize('payload',[[],{'elements':None},{'elements':['bad']},{'elements':[{'type':'node','id':123,'tags':None}]}])
def test_bad_osm_payload_fails_closed(payload):
    with pytest.raises(ValueError):
        metadata_record(payload,'AU-OSM-n123','now',{'status':'verified'},'hash')


def test_osm_and_input_conflict_keeps_both_for_review():
    result=supplied_match(target(),[source()])
    evidence={'tags':{'website':'https://different.example/'},'source_url':osm_url('AU-OSM-n123')}
    result=apply_osm(result,evidence)
    assert not result['resolved_url']
    assert json.loads(result['candidate_urls'])==['https://different.example/','https://storage.example/branch/']


def test_osm_lifecycle_flags_do_not_supply_scraping_url():
    evidence={'tags':{'website':'https://closed.example/','disused:shop':'storage_rental'},'source_url':osm_url('AU-OSM-n123')}
    result=apply_osm(supplied_match(target(),[source()]),evidence)
    assert result['resolution_status']=='osm_lifecycle_review' and not result['resolved_url']


def test_metadata_cache_integrity(tmp_path):
    data=metadata_record({'elements':[{'type':'node','id':123,'tags':{'website':'https://storage.example/'}}]},
                         'AU-OSM-n123','2026-10-20T00:00:00Z',{'status':'verified'},'hash')
    path=tmp_path/'metadata.json';path.write_text(json.dumps(data))
    assert read_metadata_cache(path,'AU-OSM-n123')['tags']==data['tags']
    data['tags']['website']='https://tampered.example/';path.write_text(json.dumps(data))
    with pytest.raises(ValueError,match='altered'):
        read_metadata_cache(path,'AU-OSM-n123')


def test_json_transport_keeps_robots_gate_and_checks_content_type():
    url='https://storage.example/metadata.json'
    client,session=client_with({'https://storage.example/robots.txt':FakeResponse('User-agent: *\nDisallow: /metadata'),
                               url:FakeResponse('{}',headers={'Content-Type':'application/json'})})
    with pytest.raises(AccessFailure) as failure:
        client.fetch_json(url)
    assert failure.value.status=='robots_disallow' and len(session.calls)==1
    client,session=client_with({'https://storage.example/robots.txt':FakeResponse('User-agent: *\nDisallow:'),
                               url:FakeResponse('{}',headers={'Content-Type':'application/json'})})
    assert client.fetch_json(url)[0]=='{}'
    with pytest.raises(AccessFailure,match='Expected'):
        client.fetch(url)


def test_uploaded_file_url_research_preserves_input(tmp_path):
    root=Path(__file__).resolve().parents[1]
    path=root/'competitors_missing_2026-10-20.csv'
    before=hashlib.sha256(path.read_bytes()).hexdigest()
    assert main(['--input',str(path),'--url-map',str(root/'reviewed_facility_urls.csv'),
                 '--output-dir',str(tmp_path)])==2
    summary=json.loads((tmp_path/'url_research_summary.json').read_text())
    assert summary['input_missing_urls']==45
    assert summary['additional_urls_resolved']==1
    assert summary['remaining_without_resolved_url']==44
    assert hashlib.sha256(path.read_bytes()).hexdigest()==before
