import csv
import json
from pathlib import Path
from decimal import Decimal
import pytest
import export_competitor_daily as e

ROOT=Path(e.__file__).parent


def example():
    rows=e.read(ROOT/'national_storage_units.csv')
    row=next(r for r in rows if r['facility_name']=='National Storage Croydon South' and r['size_m2']=='3')
    source=next(r for r in e.read(ROOT/'cannot_scrape.csv') if r['store_id']==row['store_id'])
    return row,source


def test_actual_price_mapping_gst_promotion_and_capture_date():
    row,source=example()
    output=e.convert(row,source,{('AU','boronia'):'832'})
    assert list(output)==json.loads((ROOT/'competitor_daily_schema.json').read_text())
    assert output['competitor_store_id']==row['store_id']
    assert output['subject_store_id']=='832'
    assert output['captured_on']=='2026-10-20' # Collection was Oct 19 UTC, Oct 20 Sydney.
    assert output['week_ending']=='2026-10-25'
    assert output['regular_price_inc_gst']=='90.00'
    assert output['online_price_inc_gst']=='45.00'
    assert output['price_per_m2_inc_gst']=='30.00' # Reference uses regular price / area.
    assert not any('effective_price' in key or 'ex_gst' in key for key in output)
    assert output['promo_text']=='50% for 2 months'
    assert output['promo_pct']=='50' and output['promo_months']=='2'
    assert output['promo_parsed']=='1'
    assert output['unit_size']=='1.5m x 2m' and output['access']=='GR'
    assert output['store_storage_total_m2']==''
    assert output['store_parking_rentable_m2']==''


def test_unknown_or_ambiguous_subject_ids_are_not_invented():
    row,source=example()
    subjects=e.subject_lookup([
        {'country':'AU','subject_store_name':'Boronia','subject_store_id':'first'},
        {'country':'AU','subject_store_name':'Boronia','subject_store_id':'second'},
        {'country':'NZ','subject_store_name':'Boronia','subject_store_id':'wrong-country'},
    ])
    output=e.convert(row,source,subjects)
    assert output['subject_store_id']==''
    assert output['subject_store_name']=='Boronia'


def test_promotion_uses_actual_rounded_advertised_price_without_double_discount():
    row,source=example()
    row={**row,'standard_price_aud':'95','advertised_price_aud':'47',
         'promotion':'Three Months 50% Off*','promotion_duration':'for 3 months'}
    output=e.convert(row,source,{})
    assert output['regular_price_inc_gst']=='95.00'
    assert output['online_price_inc_gst']=='47.00'
    assert output['promo_pct']=='50' and output['promo_months']=='3'
    assert not any('effective_price' in key for key in output)


def test_no_promotion_uses_advertised_rate_without_inventing_terms():
    row,source=example()
    row={**row,'advertised_price_aud':'80','promotion':'','promotion_duration':''}
    output=e.convert(row,source,{})
    assert output['promo_parsed']=='0'
    assert output['promo_pct']==output['promo_months']==''
    assert output['online_price_inc_gst']=='80.00'
    assert output['promo_text']==''


def test_unknown_promotion_does_not_guess_percentage_or_months():
    row,source=example()
    output=e.convert({**row,'promotion':'Special offer: contact us','promotion_duration':''},source,{})
    assert output['promo_parsed']=='0'
    assert output['promo_pct']==output['promo_months']==''
    assert output['promo_text']=='Special offer: contact us'


@pytest.mark.parametrize('size,expected',[('1','0-1'),('3.5','1-3.5'),('3.51','3.5-7'),('100','68-100'),('100.1','100+')])
def test_size_band_boundaries(size,expected):
    assert e.size_band(size)==expected


def test_non_monthly_prices_are_not_labelled_monthly():
    row,source=example()
    with pytest.raises(ValueError,match='non-monthly'):
        e.convert({**row,'billing_period':'week'},source,{})


def test_complete_export_matches_all_35_columns_and_preserves_listing_count(tmp_path,monkeypatch):
    import sys
    output=tmp_path/'daily.csv'
    monkeypatch.setattr(sys,'argv',['export','--units',str(ROOT/'national_storage_units.csv'),
        '--source',str(ROOT/'cannot_scrape.csv'),'--subjects',str(ROOT/'subject_store_lookup.csv'),
        '--schema',str(ROOT/'competitor_daily_schema.json'),'--output',str(output)])
    assert e.main()==0
    with output.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f)
        assert reader.fieldnames==json.loads((ROOT/'competitor_daily_schema.json').read_text())
        rows=list(reader)
    assert len(rows)==287
    assert len({r['competitor_store_id'] for r in rows})==96
    assert sum(not r['subject_store_id'] for r in rows)==24
    assert sum(r['promo_parsed']=='1' for r in rows)==223
    for row in rows:
        assert row['country']=='AU' and row['brand']=='National Storage'
        assert len(row)==35 and None not in row
        assert Decimal(row['regular_price_inc_gst'])>0
        assert Decimal(row['online_price_inc_gst'])>0
        assert row['captured_on']=='2026-10-20'
