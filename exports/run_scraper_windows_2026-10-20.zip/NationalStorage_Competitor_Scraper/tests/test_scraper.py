import csv
import json
import pytest
from pathlib import Path
import national_storage_scraper as s

# Synthetic examples, not evidence of the National Storage DOM.
def test_hidden_units_and_prices():
    html='''<article class="unit-card">9 m² 3m x 3m <del>$200</del>
    $100 per month 50% off Available</article><div hidden>
    <article class="unit-card">12 m2 $250 per month Sold out</article></div>'''
    rows=s.scrape_units(html,{'store_id':'test','nearest_kss_km':'2.3'},'fixture')
    assert len(rows)==2
    assert rows[0]['size_m2']=='9'
    assert rows[0]['standard_price']=='$200'
    assert rows[0]['advertised_price']=='$100 per month'
    assert rows[0]['promotion']=='50% off'
    assert rows[0]['availability']=='available'
    assert rows[0]['dimensions']=='3m x 3m'
    assert rows[0]['nearest_kss_km']=='2.3'
    assert rows[1]['availability']=='unavailable'

def test_no_size_no_inventory():
    assert s.scrape_units('<article class="unit-card">Call us $100</article>',{},'fixture')==[]

def test_urls():
    assert s.centre_url('/locations/springwood/')==s.BASE+'/locations/springwood/'
    for url in ['https://nationalstorage.com.au/','https://evil.example/locations/a/','https://nationalstorage.nz/locations/albany/']:
        assert not s.centre_url(url)

def test_source_scope():
    with (Path(s.__file__).parent/'cannot_scrape.csv').open(encoding='utf-8-sig') as f:
        rows=[r for r in csv.DictReader(f) if r['brand'].strip().lower()=='national storage']
    assert len(rows)==111
    assert sum(r['country']=='AU' for r in rows)==101
    assert sum(bool(s.centre_url(r['web_page'])) for r in rows)==95

def test_failed_robots_still_reports_every_target(tmp_path, monkeypatch):
    import sys
    def fail(*args, **kwargs):
        raise s.requests.exceptions.ProxyError('Tunnel connection failed: 403 Forbidden')
    monkeypatch.setattr(s.requests.Session,'get',fail)
    monkeypatch.setattr(sys,'argv',['scraper','--limit','0','--output',str(tmp_path/'units.csv'),'--status',str(tmp_path/'status.csv')])
    assert s.main() == 2
    with (tmp_path/'status.csv').open(encoding='utf-8-sig') as f:
        rows=list(csv.DictReader(f))
    from collections import Counter
    assert len(rows)==111
    assert Counter(r['status'] for r in rows)=={'robots_network_error':95,'missing_url':4,'invalid_facility_url':2,'outside_australia':10}
    assert all(r['facility_request_attempted']=='False' for r in rows)
    assert all(r['http_status']=='' for r in rows)
    assert len({r['store_id'] for r in rows})==111
    assert list(csv.DictReader((tmp_path/'units.csv').open(encoding='utf-8-sig')))==[]

def test_block_stops_requests_but_keeps_remaining_statuses(tmp_path,monkeypatch):
    import sys
    calls=[]
    class Response:
        def __init__(self,status,text): self.status_code,self.text=status,text
    def get(self,url,**kwargs):
        calls.append(url)
        return Response(200,'User-agent: *\nAllow: /') if url.endswith('robots.txt') else Response(403,'Access denied')
    monkeypatch.setattr(s.requests.Session,'get',get)
    monkeypatch.setattr(s.time,'sleep',lambda _:None)
    monkeypatch.setattr(sys,'argv',['scraper','--limit','0','--output',str(tmp_path/'units.csv'),'--status',str(tmp_path/'status.csv')])
    assert s.main() == 2
    rows=list(csv.DictReader((tmp_path/'status.csv').open(encoding='utf-8-sig')))
    assert len(calls)==2
    assert sum(r['status']=='access_denied' for r in rows)==1
    assert sum(r['status']=='not_attempted_after_block' for r in rows)==94
    assert len(rows)==111


@pytest.mark.parametrize('code,body,expected',[
    (403,'<title>Attention Required! | Cloudflare</title>Sorry, you have been blocked', 'cloudflare_or_access_block'),
    (200,'<title>Just a moment...</title>', 'cloudflare_or_access_block'),
    (403,'Forbidden', 'access_denied'),
    (429,'Too many requests', 'rate_limited'),
    (503,'Temporarily unavailable', 'service_unavailable'),
    (302,'Redirect', 'unverified'),
    (200,'<html><body>Not robots</body></html>', 'unverified'),
])
def test_robots_gates_all_facility_requests(tmp_path, monkeypatch, code, body, expected):
    import sys
    calls=[]
    def get(self,url,**kwargs):
        calls.append(url)
        assert kwargs['allow_redirects'] is False
        return type('Response', (), {'status_code':code, 'text':body})()
    monkeypatch.setattr(s.requests.Session,'get',get)
    monkeypatch.setattr(sys,'argv',['scraper','--limit','0','--output',str(tmp_path/'units.csv'),'--status',str(tmp_path/'status.csv')])
    assert s.main()==2
    assert calls==[s.BASE+'/robots.txt']
    rows=list(csv.DictReader((tmp_path/'status.csv').open(encoding='utf-8-sig')))
    assert sum(r['status']=='robots_'+expected for r in rows)==95
    assert not any(r['http_status'] for r in rows)  # No facility HTTP responses.
    assert all(r['robots_http_status']==str(code) for r in rows)
    summary=json.loads((tmp_path/'status.summary.json').read_text())
    assert summary['robots_check']['status']==expected
    assert summary['facility_requests']==0
    assert summary['units_extracted']==0


def test_network_error_does_not_export_credentials():
    class Session:
        def get(self,*args,**kwargs):
            raise s.requests.exceptions.ProxyError('https://secret-user:secret-password@proxy.example')
    _, evidence=s.check_robots(Session())
    assert 'secret' not in json.dumps(evidence)


def test_robots_disallow_without_facility_requests(tmp_path, monkeypatch):
    import sys
    calls=[]
    def get(self,url,**kwargs):
        calls.append(url)
        return type('Response', (), {'status_code':200, 'text':'User-agent: *\nDisallow: /locations/'})()
    monkeypatch.setattr(s.requests.Session,'get',get)
    monkeypatch.setattr(sys,'argv',['scraper','--limit','0','--output',str(tmp_path/'units.csv'),'--status',str(tmp_path/'status.csv')])
    assert s.main()==2
    assert calls==[s.BASE+'/robots.txt']
    rows=list(csv.DictReader((tmp_path/'status.csv').open(encoding='utf-8-sig')))
    assert sum(r['status']=='robots_disallow' for r in rows)==95

@pytest.mark.parametrize('slug,areas,regular,current,promos',[
    ('croydon-south',['3','5.04','13.5'],['90','140','323'],['45','70','242'],['Two Months 50% Off*','50% off 1st Month*','25% off 1st Month*']),
    ('box-hill',['2.72','5.7','13.52'],['95','144','290'],['47','144','290'],['Three Months 50% Off*','','']),
    ('st-marys',['3','6','13.2'],['97','118','361'],['73','88','361'],['25% off 1st Month*','25% off 1st Month*','']),
    ('artarmon',['2.25','5','13.5'],['85','162','513'],['85','162','385'],['','','25% off 1st Month*']),
])
def test_real_facility_cards(slug,areas,regular,current,promos):
    html=(Path(__file__).parent/'fixtures'/f'{slug}.html').read_text()
    rows=s.scrape_units(html,{'store_id':'test'},s.BASE+f'/locations/{slug}/')
    assert len(rows)==3
    assert [r['size_m2'] for r in rows]==areas
    assert [r['standard_price_aud'] for r in rows]==regular
    assert [r['advertised_price_aud'] for r in rows]==current
    assert [r['promotion'] for r in rows]==promos
    assert all(r['billing_period']=='month' for r in rows)
    assert all(r['facility_name'].startswith('National Storage ') for r in rows)
    assert all(r['facility_address'] and r['facility_city'] and r['facility_state'] for r in rows)
    assert all(len(r['facility_postcode'])==4 for r in rows)
    assert all(r['availability']=='offered_online' for r in rows)
    assert all(r['inventory_coverage']=='partial_facility_page' for r in rows)
    assert len({r['unit_id'] for r in rows})==3
    assert all('generally easier' not in r['features'] for r in rows)


def test_real_robots_wildcards_and_duplicate_groups():
    robot=s.Protego.parse((Path(__file__).parent/'fixtures'/'robots.txt').read_text())
    assert robot.can_fetch(s.BASE+'/locations/croydon-south/','NationalStorageResearch/1.0')
    assert robot.can_fetch(s.BASE+'/get-storage/','NationalStorageResearch/1.0')
    assert not robot.can_fetch(s.BASE+'/get-storage/all-results/503825/unit','NationalStorageResearch/1.0')
    assert not robot.can_fetch(s.BASE+'/checkout/set-unit/L121/130059/','NationalStorageResearch/1.0')
    assert not robot.can_fetch(s.BASE+'/locations/box-hill/?unit-category=s','NationalStorageResearch/1.0')


def test_real_contact_only_centre_has_no_fabricated_units():
    html=(Path(__file__).parent/'fixtures'/'springwood.html').read_text()
    assert s.scrape_units(html,{},'fixture')==[]


def test_real_card_pipeline_does_not_fetch_disallowed_all_units(tmp_path,monkeypatch):
    import sys
    fixture=Path(__file__).parent/'fixtures'
    calls=[]
    def get(self,url,**kwargs):
        calls.append(url)
        if url==s.BASE+'/robots.txt':
            body=(fixture/'robots.txt').read_text()
        elif url.endswith('/springwood/'):
            body=(fixture/'springwood.html').read_text()
        elif url.endswith('/croydon-south/'):
            body=(fixture/'croydon-south.html').read_text()
        else:
            pytest.fail('Unexpected or prohibited fetch: '+url)
        return type('Response', (), {'status_code':200,'text':body})()
    monkeypatch.setattr(s.requests.Session,'get',get)
    monkeypatch.setattr(s.time,'sleep',lambda _:None)
    monkeypatch.setattr(sys,'argv',['scraper','--limit','5','--output',str(tmp_path/'units.csv'),'--status',str(tmp_path/'status.csv'),'--save-html',str(tmp_path/'html')])
    assert s.main()==2 # Partial inventory, even though permitted cards parse.
    assert len(calls)==3
    statuses=list(csv.DictReader((tmp_path/'status.csv').open(encoding='utf-8-sig')))
    assert statuses[1]['status']=='contact_centre_no_online_units'
    assert statuses[4]['status']=='public_units_partial'
    assert statuses[4]['all_units_access']=='robots_disallow'
    assert statuses[4]['units_found']=='3'
    assert statuses[4]['unit_cards_in_html']=='3'
    units=list(csv.DictReader((tmp_path/'units.csv').open(encoding='utf-8-sig')))
    assert [r['advertised_price_aud'] for r in units]==['45','70','242']
    assert (tmp_path/'html'/'croydon-south.html').is_file()

@pytest.mark.parametrize('store_id,slug,expected,count',[
    ('AU-OSM-w23690756','hornsby','temporarily_closed',0),
    ('AU-OSM-w319636015','rowville','public_units_partial',3),
])
def test_verified_url_mapping_with_real_saved_page(tmp_path,monkeypatch,store_id,slug,expected,count):
    import sys
    fixture=Path(__file__).parent/'fixtures'
    original=list(csv.DictReader((Path(s.__file__).parent/'cannot_scrape.csv').open(encoding='utf-8-sig')))
    record=next(r for r in original if r['store_id']==store_id)
    assert not record['web_page']
    with (tmp_path/'source.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(record));writer.writeheader();writer.writerow(record)
    url=s.BASE+f'/locations/{slug}/'
    with (tmp_path/'map.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['store_id','centre_url']);writer.writeheader();writer.writerow({'store_id':store_id,'centre_url':url})
    calls=[]
    def get(self,target,**kwargs):
        calls.append(target)
        if target==s.BASE+'/robots.txt':body=(fixture/'robots.txt').read_text()
        elif target==url:body=(fixture/f'{slug}.html').read_text()
        else:pytest.fail('Unexpected fetch: '+target)
        return type('Response', (), {'status_code':200,'text':body})()
    monkeypatch.setattr(s.requests.Session,'get',get)
    monkeypatch.setattr(s.time,'sleep',lambda _:None)
    monkeypatch.setattr(sys,'argv',['scraper','--input',str(tmp_path/'source.csv'),'--url-map',str(tmp_path/'map.csv'),'--limit','0','--output',str(tmp_path/'units.csv'),'--status',str(tmp_path/'status.csv')])
    assert s.main()==2
    assert calls==[s.BASE+'/robots.txt',url]
    status=list(csv.DictReader((tmp_path/'status.csv').open(encoding='utf-8-sig')))[0]
    assert status['status']==expected
    assert status['centre_url']==url and status['original_url']==''
    units=list(csv.DictReader((tmp_path/'units.csv').open(encoding='utf-8-sig')))
    assert len(units)==count
    if slug=='rowville':
        assert [r['advertised_price_aud'] for r in units]==['70','57','398']
    else:
        assert 'closed for major upgrades' in status['details']
