"""Verify the runner preserves results and reuses access-policy state."""
import hashlib
import json

import requests

from competitor_access import PublicClient
from competitor_scraper import Checkpoint, VERSION, initial_status, load_records, snapshot, write_csv
from competitor_extract import parse_page
from run_local_scrape import INPUT, URL_MAP, OUTPUT, run_worker
from test_competitor_scraper import FakeResponse, client_with


def setup_run(root):
    rows=[{'store_id':str(i),'brand':brand,'store_name':brand+' Test','country':'AU',
           'website':f'https://storage{i}.example/facility/'}
          for i,brand in enumerate(('StoreLocal','Wilson Storage','Loxon Storage'),1)]
    write_csv(root/INPUT,list(rows[0]),rows)
    (root/'url_research').mkdir()
    write_csv(root/URL_MAP,['store_id','website'],[])
    records=load_records(root/INPUT,root/URL_MAP)
    identity=hashlib.sha256(json.dumps([VERSION,'live',records],sort_keys=True).encode()).hexdigest()
    output=root/OUTPUT;output.mkdir()
    db=Checkpoint(output/'checkpoint.sqlite3',identity,False)
    results={}
    for r in records:
        result={'status':initial_status(r,'live'),'offers':[],'promotions':[]}
        result['status']['status']='network_proxy_error'
        db.save(result);results[r['store_id']]=result
    db.close()
    snapshot(output,records,results,{},'live')
    return records


def test_denied_preflight_preserves_checkpoint_and_price_files(tmp_path):
    records=setup_run(tmp_path)
    replies={r['website'].split('/facility/')[0]+'/robots.txt':requests.exceptions.ProxyError('secret-proxy-details') for r in records}
    client,session=client_with(replies)
    before={p.name:p.read_bytes() for p in (tmp_path/OUTPUT).iterdir() if p.is_file()}
    def forbidden(*args,**kwargs):
        raise AssertionError('Collection must not start when all probes are denied')
    assert run_worker(tmp_path,client=client,collector=forbidden)==3
    assert len(session.calls)==3
    assert before=={p.name:p.read_bytes() for p in (tmp_path/OUTPUT).iterdir() if p.is_file()}
    report=json.loads((tmp_path/'local_run_logs/network_preflight.json').read_text())
    assert report['collection_started'] is False
    assert all(r['status']=='network_proxy_error' for r in report['checks'])
    assert 'secret-proxy-details' not in json.dumps(report)


def test_successful_preflight_reuses_robots_and_extracts_prices(tmp_path):
    records=setup_run(tmp_path)
    replies={}
    for r in records:
        replies[r['website'].split('/facility/')[0]+'/robots.txt']=FakeResponse('User-agent: *\nDisallow: /private')
        replies[r['website']]=FakeResponse('<div class="unit-card"><h3>Storage unit 3m2</h3><p>$99/month including GST</p></div>')
    client,session=client_with(replies)
    assert run_worker(tmp_path,client=client)==0
    assert len([u for u in session.calls if u.endswith('/robots.txt')])==3
    assert len([u for u in session.calls if u.endswith('/facility/')])==3
    report=json.loads((tmp_path/'local_run_logs/run_summary.json').read_text())
    assert report['collection_started'] is True and report['additional_offers']==3
    assert report['stores_with_offers_after']==3


def test_preflight_only_never_collects_facility_prices(tmp_path):
    records=setup_run(tmp_path)
    replies={r['website'].split('/facility/')[0]+'/robots.txt':FakeResponse('User-agent: *\nDisallow:') for r in records}
    client,session=client_with(replies)
    assert run_worker(tmp_path,preflight_only=True,client=client)==0
    assert len(session.calls)==3 and all(u.endswith('/robots.txt') for u in session.calls)
    coverage=json.loads((tmp_path/OUTPUT/'coverage.json').read_text())
    assert coverage['offers']==0


def test_retry_retains_existing_price_and_original_capture_time(tmp_path):
    records=setup_run(tmp_path)
    identity=hashlib.sha256(json.dumps([VERSION,'live',records],sort_keys=True).encode()).hexdigest()
    output=tmp_path/OUTPUT
    db=Checkpoint(output/'checkpoint.sqlite3',identity,True)
    results=db.read()
    captured='2026-10-19T02:00:00+00:00'
    offers,_,_=parse_page('<div class="unit-card"><h3>Storage unit 3m2</h3><p>$75/month including GST</p></div>',records[0],records[0]['_url'],captured)
    result=results[records[0]['store_id']]
    result['offers']=offers;result['status'].update(status='public_units_partial',offers_found=1)
    db.save(result);db.close()
    snapshot(output,records,results,{},'live')
    replies={}
    for record in records:
        replies[record['_url'].split('/facility/')[0]+'/robots.txt']=FakeResponse('User-agent: *\nDisallow:')
        replies[record['_url']]=FakeResponse('<div class="unit-card"><h3>Storage unit 3m2</h3><p>$99/month including GST</p></div>')
    client,session=client_with(replies)
    assert run_worker(tmp_path,client=client)==0
    assert records[0]['_url'] not in session.calls
    db=Checkpoint(output/'checkpoint.sqlite3',identity,True)
    retained=db.read()[records[0]['store_id']]['offers'][0];db.close()
    assert retained['online_price_inc_gst']=='75' and retained['captured_at']==captured
    summary=json.loads((tmp_path/'local_run_logs/run_summary.json').read_text())
    assert (summary['prior_offers'],summary['offers_after'],summary['additional_offers'])==(1,3,2)


def test_site_specific_denials_do_not_stop_unrelated_publishers(tmp_path):
    records=setup_run(tmp_path)
    extra={'store_id':'4','brand':'Independent Storage','store_name':'Independent Test','country':'AU','website':'https://independent.example/facility/'}
    rows=[{k:r[k] for k in ('store_id','brand','store_name','country','website')} for r in records]+[extra]
    write_csv(tmp_path/INPUT,list(extra),rows)
    records=load_records(tmp_path/INPUT,tmp_path/URL_MAP)
    identity=hashlib.sha256(json.dumps([VERSION,'live',records],sort_keys=True).encode()).hexdigest()
    output=tmp_path/OUTPUT
    (output/'checkpoint.sqlite3').unlink()
    db=Checkpoint(output/'checkpoint.sqlite3',identity,False)
    results={}
    for r in records:
        result={'status':initial_status(r,'live'),'offers':[],'promotions':[]}
        result['status']['status']='network_proxy_error'
        db.save(result);results[r['store_id']]=result
    db.close();snapshot(output,records,results,{},'live')
    replies={r['_url'].split('/facility/')[0]+'/robots.txt':FakeResponse('Denied',403) for r in records[:3]}
    replies['https://independent.example/robots.txt']=FakeResponse('User-agent: *\nDisallow:')
    replies[extra['website']]=FakeResponse('<div class="unit-card"><h3>Storage 3m2</h3><p>$50/month including GST</p></div>')
    client,session=client_with(replies)
    assert run_worker(tmp_path,client=client)==2
    assert extra['website'] in session.calls and len(session.calls)==5
    summary=json.loads((tmp_path/'local_run_logs/run_summary.json').read_text())
    assert summary['additional_offers']==1
