"""Money pairing, policy enforcement, provenance and whole-input coverage checks."""
import csv
import hashlib
import json
from pathlib import Path

import pytest
import requests

from competitor_access import AccessFailure, PublicClient, public_url
from competitor_extract import parse_page, promotion
from competitor_scraper import Checkpoint, ReplayClient, collect, daily_offer, load_records, main

NOW = '2026-10-20T05:00:00+00:00'
URL = 'https://storage.example/facility/test/'


@pytest.fixture
def record():
    return dict(store_id='AU-1', brand='Test Storage', store_name='Test Store', country='AU',
                address='1 Test Road', city='Test', website=URL, _url=URL, _needs_location=False)


def page(html, record):
    return parse_page(html, record, URL, NOW)


def test_real_national_storage_prices_and_promo(record):
    html = (Path(__file__).parent / 'fixtures/croydon-south.html').read_text()
    rows, _, info = parse_page(html, record, 'https://nationalstorage.com.au/locations/croydon-south/', NOW)
    assert len(rows) == 3
    assert info['status'] == 'public_units_partial'
    first = rows[0]
    assert (first['regular_price_inc_gst'], first['online_price_inc_gst']) == ('90', '45')
    assert (first['promo_pct'], first['promo_months'], first['billing_period']) == ('50', '2', 'month')
    assert first['captured_at'] == NOW
    assert first['inventory_coverage'] == 'partial_public_pages'
    assert first['availability'] == 'offered_online'
    daily, reason = daily_offer(first, {})
    assert not reason and daily['online_price_inc_gst'] == '45'
    assert 'effective_monthly_price_inc_gst' not in daily


def test_table_preserves_weekly_monthly_and_excludes_deposit(record):
    html = '''<p>Prices include GST.</p><table><tr><th>Unit size</th><th>Weekly price</th><th>Monthly price</th><th>Deposit</th></tr>
    <tr><td>Storage 3 × 2m</td><td>$35</td><td>$140</td><td>$200</td></tr></table>'''
    rows, _, _ = page(html, record)
    assert {(r['billing_period'], r['online_price_inc_gst']) for r in rows} == {('week', '35'), ('month', '140')}
    assert {r['size_m2'] for r in rows} == {'6'}
    assert daily_offer(rows[0], {})[1] == 'nonmonthly_or_unknown_billing_period'
    assert daily_offer(rows[1], {})[0]['online_price_inc_gst'] == '140'


def test_regular_sale_columns_are_paired_not_averaged(record):
    html = '''<p>GST inclusive</p><table><tr><th>Size</th><th>Regular monthly price</th><th>Online monthly price</th><th>Promotion</th></tr>
    <tr><td>9m<sup>2</sup></td><td>$200</td><td>$100</td><td>50% off for 2 months</td></tr></table>'''
    rows, _, _ = page(html, record)
    assert len(rows) == 1
    assert (rows[0]['regular_price_inc_gst'], rows[0]['online_price_inc_gst']) == ('200', '100')
    assert (rows[0]['promo_pct'], rows[0]['promo_months']) == ('50', '2')


@pytest.mark.parametrize('country,expected', [('AU', '110.00'), ('NZ', '115.00')])
def test_explicit_exclusive_tax_is_added(country, expected, record):
    record['country'] = country
    rows, _, _ = page('<div class="unit-card"><h3>Storage unit 10m2</h3><p>$100 per month + GST</p></div>', record)
    assert rows[0]['online_price_advertised'] == '100'
    assert rows[0]['online_price_inc_gst'] == expected


def test_unknown_tax_and_from_prices_do_not_enter_daily(record):
    rows, _, _ = page('<div class="unit-card"><h3>Storage 3m2</h3><p>From $45 per week</p></div>', record)
    assert rows[0]['online_price_advertised'] == '45'
    assert rows[0]['online_price_inc_gst'] == ''
    assert rows[0]['price_qualifier'] == 'from'
    assert daily_offer(rows[0], {})[0] is None


def test_ambiguous_card_and_marketing_prices_not_fabricated(record):
    html = '''<h1>Storage from $10!</h1><p>Insurance $20 per month.</p>
    <div class="unit-card"><h3>Storage 3m2</h3><p>$90 or $70</p></div>
    <table><tr><th>Size</th><th>Insurance price</th></tr><tr><td>3m2</td><td>$20</td></tr></table>'''
    assert page(html, record)[0] == []


def test_single_currency_sign_range_is_not_an_exact_rate(record):
    assert not page('<div class="unit-card"><h3>Storage 3m2</h3><p>$90 - 120 per month</p></div>', record)[0]


def test_unavailable_unit_without_price_is_retained(record):
    rows, _, _ = page('<div class="unit-card"><h3>Storage 3m2</h3><p>Sold out. Contact us.</p></div>', record)
    assert len(rows) == 1 and rows[0]['availability'] == 'unavailable'
    assert rows[0]['online_price_advertised'] == ''
    assert daily_offer(rows[0], {})[0] is None


def test_card_sale_and_distinct_unit_ids(record):
    html = ''.join(f'''<div class="unit-card" data-unit-id="{uid}"><h3>Storage 3m2</h3>
    <del>$80</del><span class="sale-price">$40/month</span><p>GST included. 50% off first two months. Sold out.</p></div>''' for uid in ('A', 'B'))
    rows, _, _ = page(html, record)
    assert len(rows) == 2
    assert all(r['availability'] == 'unavailable' for r in rows)
    assert all((r['regular_price_inc_gst'], r['online_price_inc_gst'], r['promo_months']) == ('80', '40', '2') for r in rows)


def test_jsonld_product_ignores_aggregate_and_nonstorage(record):
    data = {'@graph': [
        {'@type': 'Product', 'name': 'Storage unit 6m2', 'sku': 'S6', 'offers': {'@type': 'Offer', 'price': '99.50', 'priceCurrency': 'AUD',
         'availability': 'https://schema.org/InStock', 'priceSpecification': {'unitCode': 'MON', 'valueAddedTaxIncluded': True}}},
        {'@type': 'Product', 'name': 'Storage 10m2', 'offers': {'@type': 'AggregateOffer', 'lowPrice': 20, 'highPrice': 80}},
        {'@type': 'Product', 'name': 'Insurance', 'offers': {'price': 10}}]}
    rows, _, _ = page('<script type="application/ld+json">' + json.dumps(data) + '</script>', record)
    assert len(rows) == 1
    assert rows[0]['online_price_inc_gst'] == '99.50'
    assert rows[0]['availability'] == 'advertised_available'
    assert rows[0]['billing_period'] == 'month'


@pytest.mark.parametrize('value,expected', [('50% off for 2 months', ('50','2')), ('50% off 1st Month', ('50','1')),
    ('First month free', ('100','1')), ('Half price for three months', ('50','3')), ('25% off', ('25','')),
    ('Up to 50% off for 2 months', ('50','2'))])
def test_explicit_promotions(value, expected):
    assert promotion(value) == expected


def test_platform_is_reported_as_unsupported_not_empty_inventory(record):
    rows, _, info = page('<iframe src="https://example.rapidstor.test/"></iframe>', record)
    assert rows == []
    assert info['status'] == 'platform_adapter_required'
    assert info['platforms'] == ['rapidstor']


class FakeResponse:
    def __init__(self, body='', status=200, headers=None):
        self._body = body.encode()
        self.status_code, self.headers = status, headers or {}
        self.encoding = 'utf-8'
    @property
    def text(self):
        return self._content.decode('utf-8')
    @property
    def content(self):
        return self._content
    def iter_content(self, chunk_size):
        yield self._body
    def close(self):
        pass


def client_with(responses):
    class Session:
        def __init__(self):
            self.headers, self.calls = {}, []
        def get(self, url, **kwargs):
            self.calls.append(url)
            value = responses[url]
            if isinstance(value, Exception):
                raise value
            return value
    session = Session()
    return PublicClient(delay=0, session_factory=lambda: session), session


def test_robots_wildcard_all_units_not_requested(record):
    root = 'https://storage.example'
    client, session = client_with({root+'/robots.txt': FakeResponse('User-agent: *\nDisallow: /get-storage/*\n'),
                                  URL: FakeResponse('<a href="/get-storage/all-results/123/unit">View all units</a>')})
    result = collect(record, client)
    assert len(session.calls) == 2
    assert 'robots_disallow' in result['status']['warnings']
    assert result['offers'] == []


def test_allowed_view_all_is_followed(record):
    html = '<div class="unit-card"><h3>Storage 4m2</h3><p>$40 per month including GST</p></div>'
    client, session = client_with({'https://storage.example/robots.txt': FakeResponse('User-agent: *\nDisallow:'),
        URL: FakeResponse('<a href="/all-units">View all units</a>'), 'https://storage.example/all-units': FakeResponse(html)})
    result = collect(record, client)
    assert len(result['offers']) == 1 and len(session.calls) == 3
    assert result['status']['inventory_coverage'] == 'partial_public_pages'


def test_proxy_failure_pauses_publisher_without_retry(record):
    client, session = client_with({'https://storage.example/robots.txt': requests.exceptions.ProxyError('secret-proxy-details')})
    first, second = collect(record, client), collect(record, client)
    assert first['status']['status'] == 'network_proxy_error'
    assert second['status']['status'] == 'publisher_paused'
    assert len(session.calls) == 1
    assert 'secret-proxy-details' not in json.dumps(first)


@pytest.mark.parametrize('status', [403, 429])
def test_access_denial_prevents_facility_request(status, record):
    client, session = client_with({'https://storage.example/robots.txt': FakeResponse('blocked', status)})
    assert collect(record, client)['offers'] == []
    assert len(session.calls) == 1


def test_network_filter_not_mislabelled_as_website_cloudflare(record):
    client, session = client_with({'https://storage.example/robots.txt': FakeResponse('Domain forbidden', 403)})
    assert collect(record, client)['status']['status'] == 'network_policy_denied'
    assert len(session.calls) == 1


def test_redirect_checks_destination_robots_before_fetch(record):
    client, session = client_with({'https://storage.example/robots.txt': FakeResponse('User-agent: *\nDisallow: /private'),
        URL: FakeResponse('', 302, {'Location': '/private'})})
    assert collect(record, client)['status']['status'] == 'robots_disallow'
    assert len(session.calls) == 2


def test_external_booking_redirect_requires_review(record):
    client, session = client_with({'https://storage.example/robots.txt': FakeResponse('User-agent: *\nDisallow:'),
        URL: FakeResponse('', 302, {'Location': 'https://booking.other.example/123'})})
    assert collect(record, client)['status']['status'] == 'external_redirect_review'
    assert len(session.calls) == 2


def test_robots_html_is_unverified(record):
    client, session = client_with({'https://storage.example/robots.txt': FakeResponse('<html>go away</html>')})
    assert collect(record, client)['status']['status'] == 'robots_unverified'
    assert len(session.calls) == 1


def test_shared_url_requires_unique_facility_address(record):
    record['_needs_location'] = True
    client, _ = client_with({'https://storage.example/robots.txt': FakeResponse('User-agent: *\nDisallow:'),
        URL: FakeResponse('<div class="unit-card"><h3>3m2</h3><p>$30/month GST included</p></div>')})
    result = collect(record, client)
    assert result['status']['status'] == 'location_context_unverified'
    assert not result['offers']


def test_replay_integrity_and_capture_time(tmp_path, record):
    html = b'<div class="unit-card"><h3>Storage 3m2</h3><p>$30/month GST included</p></div>'
    (tmp_path/'page.html').write_bytes(html)
    meta = {'url': URL, 'sha256': hashlib.sha256(html).hexdigest(), 'captured_at': NOW, 'robots': {'status':'verified'}}
    (tmp_path/'page.json').write_text(json.dumps(meta))
    result = collect(record, ReplayClient(tmp_path), mode='replay')
    assert result['offers'][0]['captured_at'] == NOW
    assert result['status']['evidence_mode'] == 'replay'
    (tmp_path/'page.html').write_text('tampered')
    with pytest.raises(ValueError, match='integrity'):
        ReplayClient(tmp_path)


def test_checkpoint_prevents_overwrite_and_changed_input(tmp_path):
    path = tmp_path/'test.sqlite3'
    db = Checkpoint(path, 'original', False)
    db.save({'status': {'store_id':'A'}, 'offers':[], 'promotions':[]})
    db.close()
    with pytest.raises(ValueError, match='already'):
        Checkpoint(path, 'original', False)
    with pytest.raises(ValueError, match='differs'):
        Checkpoint(path, 'changed', True)
    db = Checkpoint(path, 'original', True)
    assert 'A' in db.read()
    db.close()


def test_whole_uploaded_input_and_resume_network_free(tmp_path):
    source = Path(__file__).resolve().parents[1]/'competitors_missing_2026-10-20.csv'
    rows = load_records(source)
    assert len(rows) == 402 and len({r['brand'] for r in rows}) == 155
    assert sum(not r['_url'] for r in rows) == 49
    assert {r['country'] for r in rows} == {'AU', 'NZ'}
    cache, out = tmp_path/'empty_cache', tmp_path/'out'
    cache.mkdir()
    args = ['--input', str(source), '--replay-cache', str(cache), '--output-dir', str(out), '--workers','4']
    assert main(args) == 2
    report = json.loads((out/'coverage.json').read_text())
    assert report['status_counts'] == {'missing_url':49, 'not_in_replay_cache':353}
    assert report['offers'] == 0 and report['input_stores'] == 402
    assert main(args + ['--resume']) == 2
    with (out/'store_status.csv').open(encoding='utf-8-sig') as stream:
        assert len(list(csv.DictReader(stream))) == 402


def test_reviewed_missing_urls_preserve_source_fields():
    root = Path(__file__).resolve().parents[1]
    original = load_records(root/'competitors_missing_2026-10-20.csv')
    mapped = load_records(root/'competitors_missing_2026-10-20.csv', root/'reviewed_facility_urls.csv')
    changed = [(a,b) for a,b in zip(original,mapped) if a['_url'] != b['_url']]
    assert len(changed) == 6
    assert sum(not a['website'] for a,b in changed) == 4
    assert all(b['website'] == a['website'] for a,b in changed)
    assert all(b['_url'].startswith('https://nationalstorage.com.au/locations/') for a,b in changed)


def test_missing_robots_404_allows_normal_public_page(record):
    client, session = client_with({'https://storage.example/robots.txt': FakeResponse('',404), URL: FakeResponse('<h1>Storage</h1>')})
    assert collect(record,client)['status']['status'] == 'no_recognized_pricing'
    assert len(session.calls) == 2


@pytest.mark.parametrize('url', ['http://localhost/','http://127.0.0.1/','https://user:pass@storage.example/', 'file:///etc/passwd'])
def test_invalid_or_local_urls(url):
    assert not public_url(url)
