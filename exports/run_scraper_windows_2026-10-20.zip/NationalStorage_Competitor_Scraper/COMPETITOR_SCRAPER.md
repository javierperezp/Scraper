# Multi-brand storage scraper

For the latest transport diagnosis, missing-URL research and updated URL map,
read [NETWORK_AND_URLS.md](NETWORK_AND_URLS.md). Chrome impersonation was tested
through the configured proxy. Activation of the cloud allowlist is still needed;
one additional URL was recovered from supplied evidence and 44 remain unresolved.

This runner processes **all 402 records / 155 brand labels** in
`competitors_missing_2026-10-20.csv`, including Australia, New Zealand and stores
outside 10 km. It uses the supplied URLs, never sitemaps. The original CSV is
unchanged. Forty-nine rows have no supplied URL; their status is `missing_url`.

The runner extracts public National Storage cards and has conservative HTML table,
unit-card and Schema.org Product/Offer extractors. **These generic extractors are
not verified adapters for all 155 brands.** JavaScript booking portals that do not
publish recognized unit prices in their HTML require a platform-specific adapter
or a permitted provider export/API. Unsupported and inaccessible pages remain
visible in the output. No output means unverified inventory, not zero units.

## Run on Windows

Extract the complete ZIP into one folder. Keep the Python modules together.
Open a terminal in that folder. Python 3.10 or newer is required.

```powershell
py -m pip install -r requirements.txt
py competitor_scraper.py --input competitors_missing_2026-10-20.csv --url-map reviewed_facility_urls.csv --output-dir competitor_results
```

On Linux/macOS use `python3` instead of `py` (or the repository's
`.venv/bin/python`). No accounts, API keys, proxy services or browser extensions
are required. There is no .NET/PowerShell decoding step.

Prices print to the terminal as each store finishes. CSVs are written from the
start and replaced after every completed record. Close them in Excel while a run
is active so Windows allows replacement. `checkpoint.sqlite3` preserves completed
records even if CSV writing is interrupted. To stop, use Ctrl+C; some already
running requests may finish before the process exits.

Resume an interrupted run:

```powershell
py competitor_scraper.py --url-map reviewed_facility_urls.csv --output-dir competitor_results --resume
```

After resolving a network restriction or adding an extractor, retry failed stores:

```powershell
py competitor_scraper.py --url-map reviewed_facility_urls.csv --output-dir competitor_results --resume --retry-failed
```

This skips records that already yielded offers, missing/invalid URLs and explicit
closed/contact-only pages. For a fresh price capture, use a **new output directory**.
Changing the input or URL mappings also requires a new directory, protecting prior
results. Optional `--brand "Wilson Storage"` (repeatable) or `--limit 5` restricts
the run; the status file still contains all source records, with unselected rows
marked pending. A completed run with inaccessible/unresolved records exits **2**;
that means incomplete coverage, and CSVs are still saved.

Four missing AU National Storage URLs and two homepage-only URLs were already
verified by address/coordinates in the earlier collection.
`reviewed_facility_urls.csv` includes those six exact store IDs and official
facility URLs, reducing unresolved missing URLs from 49 to 45 and resolving the
two ambiguous homepage locations.
The archived URL/address evidence is in `url_resolution_evidence.json`.
The 49 count above describes the uploaded file, before these separate mappings.

Missing or corrected URLs can be provided in a reviewed CSV with columns
`store_id,website` using `--url-map reviewed_urls.csv`. These mappings do not modify
the source CSV. Resolve missing locations from official facility directories,
addresses and coordinates; never infer a unit price from another branch.

## Outputs

| File | Contents |
| --- | --- |
| `offers.csv` | All recognized unit offers, original advertised amounts, billing period, currency, tax basis, GST-inclusive amounts when established, size, features, promo percentage/months, availability evidence and original capture time. |
| `competitor_daily.csv` | Your 35-column schema with GST-inclusive fields. Only exact monthly rates with known tax basis/local currency and positive area qualify. |
| `promotions.csv` | Page-level promotional statements with stated percentages and durations. These do not establish eligibility for every unit. |
| `store_status.csv` | One row for every input store, including missing, pending, blocked, unsupported and partially extracted stores; includes checked links and warnings. |
| `brand_coverage.csv` | Store and offer counts for every brand label. |
| `coverage.json` | Coverage totals, status breakdown, extractors used and exclusions from the monthly schema. |
| `html_cache/` | Permitted HTTP-200 HTML, hashes, original timestamps and robots evidence. Block/challenge pages are not saved. |
| `checkpoint.sqlite3` | Resume data; keep it with the run. |

There is **no seven-month average**. A stated promotion becomes, for example,
`promo_pct=50`, `promo_months=2`. Unknown duration stays blank. Conditional wording
such as “up to” stays in the promotion text. An advertised online/Continue link is
not a verified live stock count or completed booking. All extracted inventories
are labelled partial.

Weekly, fortnightly and four-week rates stay in their original periods in
`offers.csv`; they are not silently converted into monthly prices. “From” prices
are labelled and excluded from the legacy monthly schema. If GST inclusion is
explicit, advertised amounts are retained. Explicit “+ GST” rates are converted
using AU 10% / NZ 15%; both original and inclusive amounts are retained. Australian
National Storage prices use its previously verified published GST-inclusive terms
(`tax_basis_evidence.json`). Otherwise GST-inclusive fields remain blank until the
tax basis is established. Prices remain in local currency, AUD or NZD.

Generic extraction deliberately rejects ambiguous price ranges, insurance/deposit
columns, complex table rows and unlabelled page-wide prices. Unknown billing period
or missing regular price remains blank. `regular_price_inc_gst` is never invented
from a discount percentage. These conservative choices can leave genuine rates
unextracted; inspect cached HTML and add a tested site-specific adapter.

## Access controls and blocked sites

The client uses ordinary verified-TLS GET requests with an identified research
user agent. It checks robots.txt, obeys crawl delays and rate limits, follows only
bounded same-publisher redirects, and checks robots again at each destination.
Default pacing is four seconds per publisher, with four independent publishers in
parallel. A restriction pauses that publisher without stopping unrelated stores.
It does not follow login, checkout, payment or reservation routes. It does not
submit forms, impersonate browsers, solve CAPTCHAs or rotate IPs.

Explicit, same-publisher “View all units” links are attempted only if allowed by
robots.txt. National Storage Australia's `/get-storage/all-results/...` route is
disallowed, so its facility cards remain partial. Links to different booking hosts
need a reviewed URL and a validated, permitted platform adapter; the runner does
not invent endpoints or download hidden multi-facility data.

`network_proxy_error` means the network/proxy request failed before a normal
website response. `network_policy_denied` identifies the observed “Domain forbidden”
filter response. Neither establishes that a website itself uses Cloudflare.
`access_denied`, `rate_limited` and challenge statuses are reported separately.
`publisher_paused` means a prior failure on that publisher prevented another
request; see the earlier store's status for the cause.

For cloud use, the supplied CSV's hosts have been saved in the environment's
network draft (`required_domains.json`). Review/save and **publish** the changes
in environment settings before retrying denied domains; saving the draft alone
does not change the active network policy. An observed canonical redirect may
require a further exact hostname addition. Legitimate alternatives for restricted
inventory include an owner-approved feed/API, provider CSV export, written
permission for automated access, or manual collection from normally accessible
public pages. Booking-platform support still needs validation after network access
is available.

## Verify and replay

```powershell
py -m pytest -q
py validate_competitor_results.py --input competitors_missing_2026-10-20.csv --output-dir competitor_results
py competitor_scraper.py --url-map reviewed_facility_urls.csv --replay-cache competitor_results/html_cache --output-dir competitor_replay
```

Replay makes **no network requests**, checks saved hashes and access evidence, and
retains original capture timestamps. It reports uncached URLs explicitly. The test
suite includes real National Storage HTML plus controlled format/network fixtures;
synthetic fixtures validate parsing logic, not live compatibility with other brands.
The coverage reports, rather than the number of tests, establish actual collection
coverage.

## Measured coverage on 20 October 2026

The delivered run is `competitor_results_2026-10-20/`. All **402 records** have a
status; none remain pending. It contains **290 advertised listings from 97
National Storage AU stores**, with 229 explicit percentage/duration promotions.
All 290 listings have known GST-inclusive monthly prices and qualify for the
35-column export. Four National Storage stores are contact-only and one is
temporarily closed. The 102 National Storage AU records were all assessed;
their accessible facility-card inventory remains partial.

For the remaining input, 117 records received a proxy error, five received the
network domain-filter response and 133 were paused after an earlier publisher
failure: **255 network-affected records**. Forty-five records still have no URL
after the six reviewed URL corrections. **No other brand's live extractor has
been validated in this environment.** Saving the network allowlist has not
activated it. Publish the saved settings before retrying those destinations;
additional platform work may then be necessary. This is not complete coverage of
155 brand labels.

The source CSV matches the upload byte for byte. Live/replay offer identity, prices
and capture times match; the 402-row identity and price audits pass. The lookup
cannot establish the nearest KSS subject ID for 24 exported rows across seven
names, so those IDs remain blank while names/distances are retained.

`national_storage_units.csv` and `cannot_scrape.csv` at the package root are
historical regression-test inputs from the earlier collection. The current
multi-brand output is in `competitor_results_2026-10-20/`.
