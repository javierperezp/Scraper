@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher was not found. Install Python 3.10 or newer from python.org.
  pause
  exit /b 1
)
py -3 run_local_scrape.py
set "scraper_exit=%ERRORLEVEL%"
echo.
if "%scraper_exit%"=="2" echo Results were saved with partial coverage. See the status and coverage files.
if "%scraper_exit%"=="3" echo The connection checks were blocked. Previous results were preserved.
if "%scraper_exit%"=="0" echo Run completed. See the output files shown above.
echo Process exit code: %scraper_exit%
pause
exit /b %scraper_exit%
