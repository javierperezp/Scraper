"""Windows/local bootstrap and resumable retry; respects the machine's proxies.

Double-click RUN_SCRAPER_WINDOWS.cmd, or run: py run_local_scrape.py
No PowerShell/.NET decoding, proxy removal, stealth, CAPTCHA or account automation.
"""
import argparse
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUT = 'competitors_missing_2026-10-20.csv'
URL_MAP = 'url_research/updated_url_map.csv'
OUTPUT = 'competitor_results_2026-10-20_updated'
PREFLIGHT_BRANDS = ('StoreLocal', 'Wilson Storage', 'Loxon Storage')


def prepare_python(root):
    """Install pinned requirements in the package's own venv, without admin rights."""
    environment = root / '.local_scraper_venv'
    python = environment / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    if not python.is_file():
        import venv
        print('Preparing a local Python environment...', flush=True)
        venv.EnvBuilder(with_pip=True).create(environment)
    requirements = root / 'requirements.txt'
    digest = hashlib.sha256(requirements.read_bytes()).hexdigest()
    marker = environment / 'requirements.sha256'
    if not marker.is_file() or marker.read_text().strip() != digest:
        print('Installing the pinned scraper dependencies...', flush=True)
        subprocess.run([str(python), '-m', 'pip', 'install', '--disable-pip-version-check', '-r', str(requirements)], check=True)
        marker.write_text(digest, encoding='utf-8')
    return python


def check_access(client, records):
    """Check actual robots access, not a TCP port or a guessed browser result."""
    from competitor_access import AccessFailure, USER_AGENT
    outcomes = []
    for brand in PREFLIGHT_BRANDS:
        record = next((r for r in records if r['brand'] == brand and r['_url']), None)
        if not record:
            continue
        url = record['_url']
        entry = {'brand': brand, 'store_id': record['store_id'], 'facility_url': url,
                 'checked_at': datetime.now(timezone.utc).isoformat(), 'can_attempt_facility': False}
        try:
            state = client.state(url)
            with state['lock']:
                if state['stopped']:
                    raise state['stopped']
                robot, policy = client.robots(url, state)
                allowed = bool(robot.can_fetch(url, USER_AGENT))
            allowed_status='robots_absent_facility_allowed' if policy['status']=='absent' else 'robots_verified_facility_allowed'
            entry.update(status=allowed_status if allowed else 'robots_disallow',
                         can_attempt_facility=allowed, robots=policy)
        except AccessFailure as exc:
            entry.update(status=exc.status, details=exc.detail, http_status=exc.http_status)
        outcomes.append(entry)
        print(f'Connection check: {brand}: {entry["status"]}', flush=True)
    return outcomes


def run_worker(root, preflight_only=False, client=None, collector=None):
    from competitor_access import PublicClient
    from competitor_scraper import main as collect, load_records
    records = load_records(root / INPUT, root / URL_MAP)
    output = root / OUTPUT
    if not (output / 'checkpoint.sqlite3').is_file():
        raise ValueError('The supplied checkpoint is missing. Extract the full ZIP before running.')
    logs = root / 'local_run_logs'
    logs.mkdir(exist_ok=True)
    client = client or PublicClient(delay=4, timeout=25, cache_dir=output / 'html_cache')
    before = json.loads((output / 'coverage.json').read_text(encoding='utf-8'))
    checks = check_access(client, records)
    report = {'checked_at': datetime.now(timezone.utc).isoformat(), 'checks': checks,
              'configured_proxies_preserved': True, 'certificate_verification_enabled': True,
              'collection_started': False, 'prior_offers': before['offers']}
    (logs / 'network_preflight.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    if preflight_only:
        print('Preflight saved. No facility prices requested.', flush=True)
        return 0 if any(c['can_attempt_facility'] for c in checks) else 3
    network_failed = bool(checks) and all(c['status'] in ('network_proxy_error','network_policy_denied','network_error') for c in checks)
    if network_failed:
        print('All three connection probes failed at the network layer. Existing results are preserved.', flush=True)
        print('See local_run_logs/network_preflight.json. No proxy settings or website restrictions were bypassed.', flush=True)
        return 3
    if not any(c['can_attempt_facility'] for c in checks):
        print('The probed websites are unavailable or restricted; other publishers will still be assessed.', flush=True)
    report['collection_started'] = True
    (logs / 'network_preflight.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print('Retrying unresolved URL records; completed stores retain their original prices and capture dates.', flush=True)
    # Reuse preflight sessions and policy state: no immediate duplicate robots
    # request, no retry of a publisher already denied, and crawl delays persist.
    args = ['--input', str(root / INPUT), '--url-map', str(root / URL_MAP),
            '--output-dir', str(output), '--subject-lookup', str(root / 'subject_store_lookup.csv'),
            '--resume', '--retry-failed', '--workers', '4', '--delay', '4']
    code = (collector or collect)(args, live_client=client)
    after = json.loads((output / 'coverage.json').read_text(encoding='utf-8'))
    report.update(collection_exit_code=code, offers_after=after['offers'],
                  additional_offers=after['offers'] - before['offers'],
                  stores_with_offers_after=after['stores_with_offers'], status_counts=after['status_counts'])
    (logs / 'run_summary.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(f'Listings before: {before["offers"]}; after: {after["offers"]}.', flush=True)
    print('Prices: ' + str(output / 'competitor_daily.csv'), flush=True)
    print('Coverage: ' + str(output / 'brand_coverage.csv'), flush=True)
    return code


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--worker', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--use-current-python', action='store_true', help='Use an already prepared interpreter')
    parser.add_argument('--preflight-only', action='store_true')
    args = parser.parse_args(argv)
    if sys.version_info < (3, 10):
        print('Python 3.10 or newer is required. Install Python from python.org.')
        return 1
    if args.worker or args.use_current_python:
        try:
            return run_worker(ROOT, args.preflight_only)
        except KeyboardInterrupt:
            print('Stopped. Completed records remain in the checkpoint.', flush=True)
            return 130
        except (OSError, ValueError, ImportError) as exc:
            print(type(exc).__name__ + ': ' + str(exc), flush=True)
            return 1
    try:
        python = prepare_python(ROOT)
    except (OSError, subprocess.CalledProcessError) as exc:
        print('Dependency setup could not complete: ' + type(exc).__name__)
        return 1
    logs = ROOT / 'local_run_logs'
    logs.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    command = [str(python), str(Path(__file__).resolve()), '--worker']
    if args.preflight_only:
        command.append('--preflight-only')
    environment = os.environ.copy()
    environment['PYTHONUTF8'] = '1'
    with (logs / ('console_' + stamp + '.log')).open('w', encoding='utf-8') as log:
        with subprocess.Popen(command, cwd=ROOT, env=environment, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace') as process:
            try:
                for line in process.stdout:
                    print(line, end='', flush=True)
                    log.write(line);log.flush()
                return process.wait()
            except KeyboardInterrupt:
                # Let the collector's interruption handler persist completed work.
                print('Stopping; allow the current request to finish saving.', flush=True)
                return process.wait()


if __name__ == '__main__':
    raise SystemExit(main())
