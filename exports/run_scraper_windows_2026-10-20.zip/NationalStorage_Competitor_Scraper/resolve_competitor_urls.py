"""Research missing facility URLs from supplied evidence and public OSM metadata.

No guessed domains, sitemap discovery, or automatic nearest-store assignment.
Facility-address matches and OSM website tags are distinct from brand homepages.
"""
import argparse
import csv
import hashlib
import json
import math
import re
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse, urlunparse

from competitor_access import AccessFailure, PublicClient, public_url, timestamp
from competitor_scraper import load_records, read_csv, write_csv

API = 'https://api.openstreetmap.org/api/0.6/'
OSM_ID = re.compile(r'^[A-Z]{2}-OSM-([nwr])(\d+)$')
TYPE = {'n': 'node', 'w': 'way', 'r': 'relation'}
GENERIC = {'', 'unnamed', 'selfstorage', 'lockers', 'storage', 'drystack'}
FIELDS = ['store_id', 'brand', 'store_name', 'address', 'city', 'country', 'lat', 'lng',
          'resolution_status', 'resolved_url', 'candidate_urls', 'source_store_ids',
          'source_kind', 'distance_m', 'notes', 'osm_lookup_status', 'osm_source_url', 'osm_current_name']


def norm(value):
    return re.sub(r'[^a-z0-9]', '', (value or '').casefold())


def address_key(value):
    value = (value or '').casefold()
    for long, short in [('street', 'st'), ('road', 'rd'), ('avenue', 'ave'), ('drive', 'dr'), ('court', 'ct')]:
        value = re.sub(r'\b'+long+r'\b', short, value)
    return ' '.join(re.findall(r'[a-z0-9]+',value))


def brand_family(value):
    key = norm(value)
    if key.startswith('mammoth'):
        return 'mammoth'
    if key.startswith('workstore'):
        return 'workstore'
    return key


def distance_m(a, b):
    try:
        values = [float(r[k]) for r in (a,b) for k in ('lat', 'lng')]
        if not all(math.isfinite(x) for x in values):
            return None
        a1,o1,a2,o2 = map(math.radians, values)
        z = math.sin((a2-a1)/2)**2 + math.cos(a1)*math.cos(a2)*math.sin((o2-o1)/2)**2
        return round(12_742_000*math.asin(math.sqrt(min(1,z))), 1)
    except (ValueError, KeyError, TypeError):
        return None


def supplied_match(record, sources):
    result = {key: record.get(key, '') for key in FIELDS}
    result.update(resolution_status='needs_public_lookup', resolved_url='', candidate_urls='[]',
                  source_store_ids='[]', source_kind='', distance_m='', notes='', osm_lookup_status='not_requested')
    address = address_key(record.get('address', ''))
    named = brand_family(record['brand']) not in GENERIC
    exact, possible, companies = [], [], []
    for source in sources:
        url = public_url(source.get('_url', source.get('url', source.get('website', ''))))
        if not url or source.get('country') != record['country']:
            continue
        same_brand = named and brand_family(source.get('brand', '')) == brand_family(record['brand'])
        matching_address = bool(address and re.search(r'\d', record.get('address','')) and address == address_key(source.get('address', '')))
        distance = distance_m(record, source)
        item = dict(source_store_id=source.get('store_id', source.get('competitor_store_id','')), url=url,
                    distance_m=distance, brand=source.get('brand',''))
        if same_brand and matching_address:
            exact.append(item)
        elif matching_address and distance is not None and distance <= 100:
            possible.append(item)
        elif same_brand:
            parsed = urlparse(url)
            item['url'] = urlunparse(parsed._replace(path='/', params='', query='', fragment=''))
            companies.append(item)
    unique = {m['url']:m for m in exact}
    if len(unique) == 1:
        match = next(iter(unique.values()))
        result.update(resolution_status='matched_supplied_brand_and_address', resolved_url=match['url'],
                      source_kind='supplied_csv', source_store_ids=json.dumps(sorted({x['source_store_id'] for x in exact})),
                      distance_m=match['distance_m'] if match['distance_m'] is not None else '',
                      notes='Exact normalized brand and numbered street address in supplied data; website has not been live-verified.')
        if match['distance_m'] is not None and match['distance_m'] > 100:
            result['notes'] += ' Coordinate conflict: review source geocoding; no coordinates were changed.'
    elif unique:
        possible.extend(exact)
        result['resolution_status'] = 'conflicting_supplied_urls'
    elif possible:
        result.update(resolution_status='same_address_different_brand_review', notes='Co-located source has a different brand; possible rebrand or data error. Not automatically assigned.')
    elif companies:
        result.update(resolution_status='brand_site_known_facility_unverified', notes='Brand homepage is known from supplied URLs; the branch URL/address is unverified. Not used for unit prices.')
    elif not named:
        result.update(resolution_status='identity_lookup_required', notes='Generic/unnamed map feature needs its OSM tags and facility identity verified.')
    candidates = possible or companies
    if candidates:
        result['candidate_urls'] = json.dumps(sorted({m['url'] for m in candidates}))
        result['source_store_ids'] = json.dumps(sorted({m['source_store_id'] for m in candidates}))
        result['source_kind'] = 'supplied_csv_candidates'
        if possible and len(possible)==1:
            result['distance_m'] = possible[0]['distance_m']
    return result


def osm_url(store_id):
    match = OSM_ID.fullmatch(store_id)
    return API + TYPE[match[1]] + '/' + match[2] + '.json' if match else ''


def metadata_record(payload, store_id, captured_at, policy, body_hash):
    match = OSM_ID.fullmatch(store_id)
    if not match:
        raise ValueError('No exact OSM object identifier')
    kind, identifier = TYPE[match[1]], int(match[2])
    if not isinstance(payload, dict) or not isinstance(payload.get('elements'), list):
        raise ValueError('Unexpected OSM payload shape')
    elements = payload['elements']
    matching = [e for e in elements if isinstance(e, dict) and e.get('type') == kind and e.get('id') == identifier]
    if len(matching) != 1:
        raise ValueError('OSM response does not contain the requested object')
    obj = matching[0]
    if not isinstance(obj.get('tags',{}),dict):
        raise ValueError('Unexpected OSM tags shape')
    # Do not retain editor names/IDs or other unrelated object metadata.
    tags = {k:str(v) for k,v in obj.get('tags',{}).items() if k in ('name','brand','operator','website','contact:website','url','contact:url','brand:website','shop','disused:shop','abandoned:shop') or k.startswith('addr:')}
    evidence = {'store_id': store_id, 'source_url': osm_url(store_id), 'captured_at': captured_at,
                'robots': policy, 'body_sha256': body_hash, 'tags': tags}
    evidence['tags_sha256'] = hashlib.sha256(json.dumps(tags, sort_keys=True).encode()).hexdigest()
    return evidence


def read_metadata_cache(path, store_id):
    data = json.loads(path.read_text(encoding='utf-8'))
    valid = (isinstance(data,dict) and isinstance(data.get('tags'),dict) and data.get('store_id') == store_id and data.get('source_url') == osm_url(store_id)
             and data.get('captured_at') and data.get('robots',{}).get('status') in ('verified','absent')
             and hashlib.sha256(json.dumps(data.get('tags'),sort_keys=True).encode()).hexdigest() == data.get('tags_sha256'))
    if not valid:
        raise ValueError('Unverified or altered OSM metadata cache')
    return data


def apply_osm(result, evidence):
    tags = evidence['tags']
    result.update(osm_lookup_status='metadata_received', osm_source_url=evidence['source_url'],
                  osm_current_name=tags.get('name',tags.get('brand','')))
    sites = {public_url(tags.get(key,'')) for key in ('website','contact:website','url','contact:url') if tags.get(key)} - {''}
    if any(key.startswith(('disused:', 'abandoned:')) for key in tags):
        result.update(resolution_status='osm_lifecycle_review', resolved_url='', candidate_urls=json.dumps(sorted(sites)),
                      notes='OSM marks this feature disused/abandoned; verify the current operator before assigning a URL.')
    elif len(sites)==1:
        site = next(iter(sites))
        if result['resolved_url'] and result['resolved_url'] != site:
            result.update(resolution_status='conflicting_osm_and_supplied_urls', resolved_url='',
                          candidate_urls=json.dumps(sorted({site,result['resolved_url']})), notes='OSM contact URL differs from supplied matched address URL; review required.')
        else:
            result.update(resolution_status='website_from_exact_osm_object',resolved_url=site,source_kind='public_osm_metadata',
                          notes='Contact website is recorded on the exact supplied OSM object. Facility website content still needs live verification.')
    elif sites:
        result.update(resolution_status='multiple_osm_websites_review',resolved_url='',candidate_urls=json.dumps(sorted(sites)),notes='Multiple contact URLs on the OSM object; not automatically assigned.')
    else:
        result['notes'] += ' Exact OSM object has no usable contact website tag.'
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', default='competitors_missing_2026-10-20.csv')
    parser.add_argument('--url-map', default='reviewed_facility_urls.csv')
    parser.add_argument('--history', action='append', default=[] ,help='Optional supplied prior CSV with country/brand/address/url/store IDs')
    parser.add_argument('--output-dir', default='url_research')
    parser.add_argument('--lookup-osm', action='store_true',help='Fetch public OSM object metadata only when robots/network allow it')
    parser.add_argument('--delay', type=float, default=2)
    args = parser.parse_args(argv)
    if args.delay < 1:
        parser.error('OSM metadata requests must be at least one second apart')
    records = load_records(args.input,args.url_map)
    missing = [r for r in records if not r['_url']]
    sources = [r for r in records if r['_url']]
    for path in args.history:
        for row in read_csv(path):
            row['store_id'] = row.get('store_id',row.get('competitor_store_id',''))
            sources.append(row)
    directory=Path(args.output_dir);directory.mkdir(parents=True,exist_ok=True)
    cache=directory/'osm_metadata';cache.mkdir(exist_ok=True)
    client = PublicClient(delay=args.delay) if args.lookup_osm else None
    results=[]
    for record in missing:
        result = supplied_match(record,sources)
        endpoint = osm_url(record['store_id'])
        result['osm_source_url'] = endpoint
        path=cache/(record['store_id']+'.json')
        try:
            if path.exists():
                result=apply_osm(result,read_metadata_cache(path,record['store_id']))
            elif client and endpoint:
                body,final,captured,proof=client.fetch_json(endpoint)
                if final != endpoint:
                    raise ValueError('Metadata endpoint redirected away from the exact requested object')
                evidence=metadata_record(json.loads(body),record['store_id'],captured,proof['robots'],proof['sha256'])
                path.write_text(json.dumps(evidence,indent=2),encoding='utf-8')
                result=apply_osm(result,evidence)
        except AccessFailure as exc:
            result['osm_lookup_status']=exc.status
        except (OSError,ValueError,TypeError) as exc:
            result['osm_lookup_status']='metadata_error_'+type(exc).__name__
        results.append(result)
    write_csv(directory/'missing_url_research.csv',FIELDS,results)
    mapped=[{'store_id':r['store_id'],'website':r['_url']} for r in records if r['_url'] and r['_url']!=public_url(r['website'])]
    mapped.extend({'store_id':r['store_id'],'website':r['resolved_url']} for r in results if r['resolved_url'])
    write_csv(directory/'updated_url_map.csv',['store_id','website'],mapped)
    summary={'generated_at':timestamp(),'input_missing_urls':len(missing),'additional_urls_resolved':sum(bool(r['resolved_url']) for r in results),
             'remaining_without_resolved_url':sum(not r['resolved_url'] for r in results),
             'statuses':dict(Counter(r['resolution_status'] for r in results)),
             'osm_lookup_statuses':dict(Counter(r['osm_lookup_status'] for r in results)),
             'no_price_data_collected':True,'notes':['Company homepages, nearby stores and different-brand matches are candidates only.',
             'URLs supplied by OSM or prior CSVs still require live facility verification.','No sitemap discovery or network/access-control bypass.']}
    (directory/'url_research_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
    return 2 if summary['remaining_without_resolved_url'] else 0


if __name__=='__main__':
    raise SystemExit(main())
